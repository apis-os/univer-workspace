import type { IMutation } from '@univerjs/core';
export interface ICreateUnitMutationParams {
    unitId: string;
}
/**
 * This mutation will not create a unit but only be a signal
 */
export declare const CreateUnitMutation: IMutation<ICreateUnitMutationParams>;
