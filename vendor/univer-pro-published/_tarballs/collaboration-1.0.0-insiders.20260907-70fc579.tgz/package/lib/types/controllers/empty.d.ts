import type { IMutationInfo } from '@univerjs/core';
export declare const EmptyMutationInfo: IMutationInfo;
