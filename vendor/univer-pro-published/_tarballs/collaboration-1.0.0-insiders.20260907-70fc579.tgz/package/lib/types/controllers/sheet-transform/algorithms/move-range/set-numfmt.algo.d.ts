import type { IMoveRangeMutationParams, ISetNumfmtMutationParams } from '@univerjs/sheets';
import type { IMutationTransformAlgorithm } from '../../../../services/transform/transform.service';
export declare const moveRangeMutationWithSetNumfmt: IMutationTransformAlgorithm<IMoveRangeMutationParams, ISetNumfmtMutationParams>;
