import type { IMoveRowsMutationParams, ISetRowHiddenMutationParams } from '@univerjs/sheets';
import type { IMutationTransformAlgorithm } from '../../../../services/transform/transform.service';
export declare const moveRowMutationWithSetRowHidden: IMutationTransformAlgorithm<IMoveRowsMutationParams, ISetRowHiddenMutationParams>;
