import type { IRemoveRowsMutationParams, ISetSelectionsOperationParams } from '@univerjs/sheets';
import type { IMutationTransformAlgorithm } from '../../../../services/transform/transform.service';
/**
 * The selection transform is a special case of mutation transform which only used at local.
 * In this case, we only need m2Prime to change current selections.
 */
export declare const removeRowMutationWithSetSelection: IMutationTransformAlgorithm<IRemoveRowsMutationParams, ISetSelectionsOperationParams>;
