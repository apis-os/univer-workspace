import type { ICellData, IObjectMatrixPrimitiveType, IRange, Nullable } from '@univerjs/core';
import { RANGE_TYPE } from '@univerjs/core';
export declare function toColumn(range: IRange): {
    rangeType: RANGE_TYPE;
    startAbsoluteRefType?: import("@univerjs/core").AbsoluteRefType;
    endAbsoluteRefType?: import("@univerjs/core").AbsoluteRefType;
    startRow: number;
    endRow: number;
    unitId?: string;
    sheetId?: string;
    startColumn: number;
    endColumn: number;
};
export declare function moveRows(o: IObjectMatrixPrimitiveType<Nullable<ICellData>>, start: number, count: number, offset: number): void;
export declare function moveColumns(o: IObjectMatrixPrimitiveType<Nullable<ICellData>>, start: number, count: number, offset: number): void;
export declare function RangeSubtractRanges(main: IRange, excepts: IRange[]): IRange[];
export declare function processFormulaString(unitId: string, subUnitId: string, formulaString: string, rangeFunc: (range: IRange) => IRange | null): string;
export declare function getRangeByFormulaString(formulaString: string): IRange[];
interface ILine {
    start: number;
    end: number;
}
export interface ISheetRangeLocation {
    range: IRange;
    subUnitId: string;
    unitId: string;
}
export declare function intersect(line1: ILine, line2: ILine): boolean;
export declare function contain(line1: ILine, line2: ILine): boolean;
export declare function lineSubtractLines(line1: ILine, lines2: ILine[]): ILine[];
export declare function lineSubtractLine(line1: ILine, line2: ILine): ILine[];
export declare function handleInsert(insert: ILine, target: ILine): ILine;
export declare function handleRemove(remove: ILine, target: ILine): ILine | null;
export {};
