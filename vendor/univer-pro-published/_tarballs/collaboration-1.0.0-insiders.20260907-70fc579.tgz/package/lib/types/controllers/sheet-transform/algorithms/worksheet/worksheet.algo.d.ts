import type { ISetWorksheetOrderMutationParams } from '@univerjs/sheets';
import type { IMutationTransformAlgorithm } from '../../../../services/transform/transform.service';
export declare const InsertSheetMutationWithSelf: IMutationTransformAlgorithm;
export declare const RemoveSheetMutationWithOthers: IMutationTransformAlgorithm;
export declare const SetWorksheetOrderMutationWithSelf: IMutationTransformAlgorithm<ISetWorksheetOrderMutationParams, ISetWorksheetOrderMutationParams>;
export declare const InsetSheetMutationWithSetWorksheetOrder: IMutationTransformAlgorithm;
export declare const OthersWithRemoveSheetMutation: IMutationTransformAlgorithm;
export declare const WorksheetAlgorithms: Array<IMutationTransformAlgorithm>;
