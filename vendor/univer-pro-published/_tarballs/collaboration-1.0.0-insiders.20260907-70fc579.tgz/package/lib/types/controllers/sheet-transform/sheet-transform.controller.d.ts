import { Disposable } from '@univerjs/core';
import { ITransformService } from '../../services/transform/transform.service';
export declare const SHEET_ALL_ALGORITHMS: import("../../services/transform/transform.service").IMutationTransformAlgorithm<any, any>[];
/**
 * This controller register sheet transform algorithms to the transform service.
 */
export declare class SheetTransformController extends Disposable {
    private readonly _transformService;
    constructor(_transformService: ITransformService);
}
