import type { UniverInstanceType } from '@univerjs/core';
import type { ICollaMsgErrorEvent, ICollaMsgJoin, ICollaMsgLeave, ICommentUpdate, ILiveShareNewHost, ILiveShareOperation, ILiveShareRequestHost, ILiveShareTerminate, IChangeset as IProtocolChangeset, IShouldCloseConn, IUniscriptRun, IUpdateCursor, IUpdatePermissionObj } from '@univerjs/protocol';
import type { IChangeset } from './changeset';
/**
 * Types of all possible collaboration events.
 *
 * CollaborationEvents is a subset of `CombEvent.RECV`.
 */
export declare enum CollaborationEvent {
    /**
     * When the collaboration session is created, the client may send this event to the server.
     * In the payload, the client will tell the server the its local revision. The server
     * could emit missing changesets to the client using event `NEW_CHANGESETS`.
     */
    FETCH_MISSING = "fetch_missing",
    /**
     * The client submit a changeset to the server.
     */
    SUBMIT_CHANGESET = "submit_changeset",
    /**
     * The submitted changeset is acknowledged by the server.
     */
    CHANGESET_ACK = "changeset_ack",
    /**
     * The submitted changeset could not be transformed by the server, so
     * the changeset should be rejected.
     */
    CHANGESET_REJ = "changeset_rej",
    /**
     * The submitted changeset could not be acknowledged by unexpected server error, so
     * the changeset should be resent.
     */
    CHANGESET_SHOULD_RETRY = "changeset_should_retry",
    /**
     * When a changeset sent by the client is acknowledged by the server,
     * the server should broadcast this changeset to other clients.
     *
     * Note that this event would not be sent via the websocket but http.
     */
    NEW_CHANGESETS = "new_changesets",
    /**
     * When a client updates its cursor position, it would send this event to
     * the server. The server would also broadcast this event to other peer
     * clients.
     */
    UPDATE_CURSOR = "update_cursor",
    /**
     * When a client connect the collaboration session, the server should
     * broadcast this event to all other clients.
     */
    USERS_ENTER = "users_enter",
    /**
     * When a client disconnect the collaboration session, the server should
     * broadcast this event to all other clients.
     */
    USERS_LEAVE = "users_leave",
    /**
     * The collaboration unit is deleted on the server.
     */
    UNIT_DELETE = "unit_delete",
    /**
     * This client requests itself to be the live share host. Sent by clients.
     */
    LIVESHARE_REQUEST_HOST = "liveshare.request_host",
    /**
     * New host is elected. Sent by the server.
     */
    LIVESHARE_NEW_HOST = "liveshare.new_host",
    /**
     * A operation sent from the live share host. Sent by the host client and
     * broadcasted by the server. For each `operation.id`, the server should
     * cache let latest value for followers who come into the live share room
     * later.
     */
    LIVESHARE_OPERATION = "liveshare.operation",
    /**
     * Fetch all operations from the live share host. for some scenarios:
     * 1. when a client comes into the live share room, it should fetch all
     * 2. when a client miss some operations, it should fetch all
     */
    LIVESHARE_FETCH_OPERATIONS = "liveshare.fetch_operations",
    /**
     * Send by the presenter to terminate live share. Should be broadcasted to
     * all followers.
     */
    LIVESHARE_TERMINATE = "liveshare.terminate",
    /**
     * This type will be returned if an error is reported.
     */
    MSG_FOR_ERROR = "error_msg",
    PERMISSION_REJ = "permission_rej",
    COMMENT_UPDATE = "comment_update",
    UPDATE_PERMISSION_OBJ = "update_permission_obj",
    SHOULD_CLOSE_CONN = "should_close_conn",
    UNISCRIPT_RUN = "uniscript.run"
}
/**
 * Awaiting mutations were acknowledged by the server.
 */
export interface IAcknowledgedChangeset {
    /** The rev of the document when this changeset is assembled. */
    baseRev: number;
    /** The rev version given by the server. */
    revision: number;
}
/**
 * Awaiting mutations were rejected by the server.
 */
export interface IRejectedChangeset {
    baseRev: number;
    revision: number;
}
/**
 * When the collaboration session is created, it should send a handshake event to the server.
 */
export interface IFetchingMissEvent {
    eventID: CollaborationEvent.FETCH_MISSING;
    data: {
        unitID: string;
        unitType: UniverInstanceType;
        from: number;
        to: number;
    };
}
export interface IPseudoFetchMissingResultEvent {
    eventID: CollaborationEvent.PSEUDO_FETCH_MISSING_RESULT;
    data: {
        changesets: IProtocolChangeset[];
    };
}
/** Receives a changeset from collaboration server. */
export interface INewChangesetsEvent {
    eventID: CollaborationEvent.NEW_CHANGESETS;
    data: IProtocolChangeset;
}
/** Send a changeset to the collaboration sever. */
export interface ISubmitChangesetEvent {
    eventID: CollaborationEvent.SUBMIT_CHANGESET;
    data: {
        unitID: string;
        unitType: UniverInstanceType;
        memberID: string;
        changeset: IChangeset;
    };
}
export interface IAcknowledgementEvent {
    eventID: CollaborationEvent.CHANGESET_ACK;
    data: IProtocolChangeset;
}
export interface IRejectionEvent {
    eventID: CollaborationEvent.CHANGESET_REJ;
    data: {
        unitID: string;
        changeset: IRejectedChangeset;
    };
}
export interface IRetryEvent {
    eventID: CollaborationEvent.CHANGESET_SHOULD_RETRY;
    data: IChangeset;
}
export interface ICollaborationUser {
    userID: string;
    memberID: string;
    name: string;
}
export interface IUserSelectionEvent {
    eventID: CollaborationEvent.UPDATE_CURSOR;
    data: {
        /** The selection is serialized. */
        selection: string;
        userID: string;
        memberID: string;
        unitID: string;
    };
}
export interface IUpdateCursorEvent {
    eventID: CollaborationEvent.UPDATE_CURSOR;
    data: IUpdateCursor;
}
export interface IUserJoinEvent {
    eventID: CollaborationEvent.USERS_ENTER;
    data: ICollaMsgJoin;
}
export interface IUserLeaveEvent {
    eventID: CollaborationEvent.USERS_LEAVE;
    data: ICollaMsgLeave;
}
/**
 * The special type for other features to reuse collaboration session.
 */
export interface ICustomEvent {
    eventID: string;
    data: any;
}
export interface IRequestHostEvent {
    eventID: CollaborationEvent.LIVESHARE_REQUEST_HOST;
    data: ILiveShareRequestHost;
}
export interface IFetchOperationsEvent {
    eventID: CollaborationEvent.LIVESHARE_FETCH_OPERATIONS;
}
export interface ITerminateEvent {
    eventID: CollaborationEvent.LIVESHARE_TERMINATE;
    data: ILiveShareTerminate;
}
export interface INewHostEvent {
    eventID: CollaborationEvent.LIVESHARE_NEW_HOST;
    data: ILiveShareNewHost;
}
export interface IOperationEvent {
    eventID: CollaborationEvent.LIVESHARE_OPERATION;
    data: ILiveShareOperation;
}
export interface IMsgErrEvent {
    eventID: CollaborationEvent.MSG_FOR_ERROR;
    data: ICollaMsgErrorEvent;
}
export interface ICommentUpdateEvent {
    eventID: CollaborationEvent.COMMENT_UPDATE;
    data: ICommentUpdate;
}
export interface IPermissionUpdateEvent {
    eventID: CollaborationEvent.UPDATE_PERMISSION_OBJ;
    data: IUpdatePermissionObj;
}
export interface IShouldCloseConnEvent {
    eventID: CollaborationEvent.SHOULD_CLOSE_CONN;
    data: IShouldCloseConn;
}
export interface IUniscriptRunEvent {
    eventID: CollaborationEvent.UNISCRIPT_RUN;
    data: IUniscriptRun;
}
/**
 * A union type of all possible collaboration events.
 */
export type ICollaborationEvent = IAcknowledgementEvent | INewChangesetsEvent | IRejectionEvent | ISubmitChangesetEvent | IPseudoFetchMissingResultEvent | IUserSelectionEvent | IFetchingMissEvent | IUpdateCursorEvent | IUserJoinEvent | IUserLeaveEvent | ICustomEvent | IRequestHostEvent | IFetchOperationsEvent | ITerminateEvent | INewHostEvent | IOperationEvent | IMsgErrEvent | ICommentUpdateEvent | IPermissionUpdateEvent | IShouldCloseConnEvent | IUniscriptRunEvent;
