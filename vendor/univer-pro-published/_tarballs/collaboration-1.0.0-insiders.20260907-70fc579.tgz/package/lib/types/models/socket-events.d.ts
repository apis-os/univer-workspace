import type { CmdRspCode, CombCmd, ICombJoinRequest, ICombJoinResponse, ICombLeaveRequest } from '@univerjs/protocol';
import type { ICollaborationEvent } from './collaboration-events';
interface ICombCmdRequest {
    cmd: CombCmd;
    routeKey: string;
    routeType: string;
    data?: unknown;
}
export interface IHelloRequestEvent extends ICombCmdRequest {
    cmd: CombCmd.HELLO;
}
export interface IJoinRequestEvent extends ICombCmdRequest {
    cmd: CombCmd.JOIN;
    data: ICombJoinRequest;
}
export interface ILeaveRequestEvent extends ICombCmdRequest {
    cmd: CombCmd.LEAVE;
    data: ICombLeaveRequest;
}
export interface IIngestQuestEvent extends ICombCmdRequest {
    cmd: CombCmd.INGEST;
    data: ICollaborationEvent;
}
export interface IHeartbeatRequestEvent extends ICombCmdRequest {
    cmd: CombCmd.HEARTBEAT;
}
export type ICombRequestEvent = IHelloRequestEvent | IJoinRequestEvent | ILeaveRequestEvent | IIngestQuestEvent | IHeartbeatRequestEvent;
interface ICombCmdResponse {
    cmd: CombCmd;
    code: CmdRspCode;
    routeKey: string;
    data?: unknown;
}
export interface IHelloResponseEvent extends ICombCmdResponse {
    cmd: CombCmd.HELLO;
    /** The client will not send `data` but the server would respond with `data`. */
    data: {
        memberID: string;
    };
}
export interface IJoinResponseEvent extends ICombCmdResponse {
    cmd: CombCmd.JOIN;
    data: ICombJoinResponse;
}
export interface IRecvResponseEvent extends ICombCmdResponse {
    cmd: CombCmd.RECV;
    data: ICollaborationEvent;
}
export interface IHeartbeatResponseEvent extends ICombCmdResponse {
    cmd: CombCmd.HEARTBEAT;
}
export type ICombResponseEvent = IHelloResponseEvent | IJoinResponseEvent | IRecvResponseEvent | IHeartbeatResponseEvent;
export {};
