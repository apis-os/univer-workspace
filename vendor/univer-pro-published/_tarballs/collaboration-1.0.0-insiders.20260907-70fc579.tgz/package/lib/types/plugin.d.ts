import type { IUniverCollaborationConfig } from './config/config';
import { IConfigService, Injector, Plugin } from '@univerjs/core';
export declare class UniverCollaborationPlugin extends Plugin {
    private readonly _config;
    protected _injector: Injector;
    private readonly _configService;
    static pluginName: string;
    static packageName: string;
    static version: string;
    constructor(_config: IUniverCollaborationConfig | undefined, _injector: Injector, _configService: IConfigService);
    onStarting(): void;
}
