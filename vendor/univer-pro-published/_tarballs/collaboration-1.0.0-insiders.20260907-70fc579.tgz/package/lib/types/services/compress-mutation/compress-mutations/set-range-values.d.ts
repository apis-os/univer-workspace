import type { ICellData, IObjectMatrixPrimitiveType, Nullable } from '@univerjs/core';
export declare const transformRefStyleFromCells: (matrix?: IObjectMatrixPrimitiveType<Nullable<ICellData>>) => {
    cellValue: undefined;
    styleRefMap: undefined;
} | {
    cellValue: IObjectMatrixPrimitiveType<Nullable<ICellData>>;
    styleRefMap: {
        [id: string]: Nullable<string | import("@univerjs/core").IStyleData>;
    };
};
export declare const transformCellsFromRefStyle: (matrix?: IObjectMatrixPrimitiveType<Nullable<ICellData>>, styleRefMap?: {
    [id: string]: ICellData["s"];
}) => IObjectMatrixPrimitiveType<Nullable<ICellData>> | undefined;
