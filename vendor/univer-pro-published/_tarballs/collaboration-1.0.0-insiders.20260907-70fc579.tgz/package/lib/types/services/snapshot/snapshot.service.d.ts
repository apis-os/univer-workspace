import type { BoardModel, IBoardData } from '@univerjs-pro/boards';
import type { IPdfUnitData, PdfDocumentModel } from '@univerjs-pro/pdfs';
import type { ISlideData, SlideModel } from '@univerjs-pro/slides';
import type { BaseDataModel, DocumentDataModel, IBaseSnapshot, ICreateUnitOptions, IDocumentData, IWorkbookData, UnitModel, Workbook } from '@univerjs/core';
import type { ICopyFileMetaRequest, ICopyFileMetaResponse, IFetchMissingChangesetsRequest, IFetchMissingChangesetsResponse, IGetDeserializedSheetBlockResponse, IGetLatestCsReqIdBySidRequest, IGetLatestCsReqIdBySidResponse, IGetResourcesRequest, IGetResourcesResponse, IGetSheetBlockRequest, IGetSheetBlockResponse, IGetUnitOnRevRequest, IGetUnitOnRevResponse, IReportUnitRoutingStatsRequest, IReportUnitRoutingStatsResponse, ISaveChangesetRequest, ISaveChangesetResponse, ISaveSheetBlockRequest, ISaveSheetBlockResponse, ISaveSnapshotRequest, ISaveSnapshotResponse, ISnapshot } from '@univerjs/protocol';
import type { ILogContext } from '../../utils';
import { ICommandService, ILogService, IResourceManagerService, IUniverInstanceService } from '@univerjs/core';
import { CompressMutationService } from '../compress-mutation/compress-mutation.service';
import { RevisionService } from '../rev/rev.service';
import { SnapshotLoadingService } from './snapshot-loading.service';
export declare function hasSlideSnapshotMeta(snapshot: ISnapshot | null | undefined): boolean;
export declare function hasBoardSnapshotMeta(snapshot: ISnapshot | null | undefined): boolean;
export declare function hasPdfSnapshotMeta(snapshot: ISnapshot | null | undefined): boolean;
/**
 * It provides implementations for server side controllers to load or save
 * or load snapshots. This service should be implemented by the host environment.
 * And it shouldn't contain any business logic.
 */
export declare const ISnapshotServerService: import("@wendellhu/redi").IdentifierDecorator<ISnapshotServerService>;
export interface ISnapshotServerService {
    /** Load snapshot from a database. */
    getUnitOnRev: (context: ILogContext, params: IGetUnitOnRevRequest) => Promise<IGetUnitOnRevResponse>;
    /** Load sheet block from a database. */
    getSheetBlock: (context: ILogContext, params: IGetSheetBlockRequest) => Promise<IGetSheetBlockResponse>;
    getDeserializedSheetBlock: (context: ILogContext, params: IGetSheetBlockRequest) => Promise<IGetDeserializedSheetBlockResponse | IGetSheetBlockResponse>;
    /** Fetch missing changeset */
    fetchMissingChangesets: (context: ILogContext, params: IFetchMissingChangesetsRequest) => Promise<IFetchMissingChangesetsResponse>;
    getResourcesRequest: (context: ILogContext, params: IGetResourcesRequest) => Promise<IGetResourcesResponse>;
    /** Save snapshot to a database. */
    saveSnapshot: (context: ILogContext, params: ISaveSnapshotRequest) => Promise<ISaveSnapshotResponse>;
    /** update snapshot to the database. */
    updateSnapshot: (context: ILogContext, params: ISaveSnapshotRequest) => Promise<ISaveSnapshotResponse>;
    /** Save sheet block to a database. */
    saveSheetBlock: (context: ILogContext, params: ISaveSheetBlockRequest) => Promise<ISaveSheetBlockResponse>;
    /** Save changeset to a database. */
    saveChangeset: (context: ILogContext, params: ISaveChangesetRequest) => Promise<ISaveChangesetResponse>;
    copyFileMeta: (context: ILogContext, params: ICopyFileMetaRequest) => Promise<ICopyFileMetaResponse>;
    getLatestCsReqIdBySid: (context: ILogContext, params: IGetLatestCsReqIdBySidRequest) => Promise<IGetLatestCsReqIdBySidResponse>;
    /** Report unit routing stats */
    reportUnitRoutingStats?: (context: ILogContext, params: IReportUnitRoutingStatsRequest) => Promise<IReportUnitRoutingStatsResponse>;
}
export interface ISnapshotLoadOptions {
    createOptions?: ICreateUnitOptions;
    initialSubUnitId?: string;
}
/**
 * The service provides methods to load snapshots from the snapshot server.
 */
export declare class SnapshotService {
    private readonly _revisionService;
    private readonly _univerInstanceService;
    private readonly _snapshotServerService;
    private readonly _commandService;
    private readonly _logService;
    private _compressMutationService;
    private _resourceManagerService;
    private readonly _snapshotLoadingService;
    private readonly _serverUnits;
    constructor(_revisionService: RevisionService, _univerInstanceService: IUniverInstanceService, _snapshotServerService: ISnapshotServerService, _commandService: ICommandService, _logService: ILogService, _compressMutationService: CompressMutationService, _resourceManagerService: IResourceManagerService, _snapshotLoadingService: SnapshotLoadingService);
    isUnitLoadedFromServer(unit: UnitModel): boolean;
    loadSheet(unitId: string, rev: number, context?: ILogContext, options?: ISnapshotLoadOptions): Promise<Workbook>;
    private _getPrioritizedSheetBlockIds;
    private _getCompressedChangesetMutations;
    loadBase(unitId: string, rev: number, context?: ILogContext, options?: ISnapshotLoadOptions): Promise<BaseDataModel>;
    loadDoc(unitID: string, rev: number, context?: ILogContext, options?: ISnapshotLoadOptions): Promise<DocumentDataModel>;
    loadSlide(unitID: string, rev?: number, context?: ILogContext, options?: ISnapshotLoadOptions): Promise<SlideModel>;
    loadBoard(unitID: string, rev?: number, context?: ILogContext, options?: ISnapshotLoadOptions): Promise<BoardModel>;
    loadPdf(unitID: string, rev?: number, context?: ILogContext, options?: ISnapshotLoadOptions): Promise<PdfDocumentModel>;
    saveSheet(_context: ILogContext, workbook: Workbook): IWorkbookData;
    saveBase(_context: ILogContext, base: BaseDataModel): IBaseSnapshot;
    saveDoc(_context: ILogContext, document: DocumentDataModel): IDocumentData;
    saveSlide(unitId: string, slideData: ISlideData, rev: number): Promise<{
        snapshot: ISnapshot;
    }>;
    saveBoard(unitId: string, boardData: IBoardData, rev: number): Promise<{
        snapshot: ISnapshot;
    }>;
    savePdf(unitId: string, pdfData: IPdfUnitData, rev: number): Promise<{
        snapshot: ISnapshot;
    }>;
}
