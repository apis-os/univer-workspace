import type { IMutationInfo } from '@univerjs/core';
import type { IChangeset } from '../../models/changeset';
import type { IFailureTransformChangesetsResult, IFailureTransformMutationResult, IFailureTransformMutationsResult, ISuccessTransformChangesetsResult, ISuccessTransformMutationResult, ISuccessTransformMutationsResult, ITransformChangesetsResult, ITransformMutationResult, ITransformMutationsResult, ITransformMutationsWithChangesetResult } from './types';
import { Disposable, ILogService } from '@univerjs/core';
/**
 * A single transform algorithm. Algorithms are registered to the transform service in the form of `{m1}-{m2}`.
 * When the transform service is transforming two mutations, it would find the algorithm by the form of `{m1}-{m2}`.
 * `m1` is the mutation on the left side, and `m2` is the mutation on the right side.
 */
export interface IMutationTransformAlgorithm<M extends object = any, N extends object = any> {
    m1: string;
    m2?: string | 'any';
    handler(m1: IMutationInfo<M>, m2: IMutationInfo<N>): ITransformMutationResult;
    handler(m1: IMutationInfo<M>, m2: IMutationInfo<N>, onlyLater?: true): Omit<ISuccessTransformMutationResult, 'm1Prime'> | IFailureTransformMutationResult;
}
/**
 * This service's responsibility is to transform mutations (changesets).
 *
 * Features could register transform algorithms to this service, so this the service could transform more mutations.
 *
 * This should be used both on client and server.
 *
 * This service is also business-agnostic, so it could be used in docs, sheets and slides.
 */
export interface ITransformService {
    /**
     * Register an algorithm to transform two kinds of mutations.
     *
     * Note that this method is not the same as other registering methods in Univer, it wouldn't return a disposable,
     * because it would cause critical problems if you unregister a transform algorithm.
     */
    registerTransformAlgorithm: (algorithms: IMutationTransformAlgorithm) => void;
    transformMutation(m1: IMutationInfo, m2: IMutationInfo, onlyLater: false): ITransformMutationResult;
    transformMutations(m1: IMutationInfo[], m2: IMutationInfo[], onlyLater: boolean): ITransformMutationsResult;
    transformChangesets(c1: IChangeset[], c2: IChangeset[], onlyLater: false): ITransformChangesetsResult;
}
export declare const ITransformService: import("@wendellhu/redi").IdentifierDecorator<ITransformService>;
export declare class TransformService extends Disposable implements ITransformService {
    private readonly _logService;
    private readonly _transformMap;
    private readonly _loopLimitTime;
    private readonly _transformMutationsCache;
    constructor(_logService: ILogService);
    dispose(): void;
    registerTransformAlgorithm(algorithm: IMutationTransformAlgorithm): void;
    transformMutation(m1: IMutationInfo, m2: IMutationInfo): ITransformMutationResult;
    transformMutation(m1: IMutationInfo, m2: IMutationInfo, onlyLater: false): ITransformMutationResult;
    transformMutation(m1: IMutationInfo, m2: IMutationInfo, onlyLater: true): IFailureTransformMutationResult | Omit<ISuccessTransformMutationResult, 'm1Prime'>;
    transformMutations(m1: IMutationInfo[], m2: IMutationInfo[]): ITransformMutationsResult;
    transformMutations(m1: IMutationInfo[], m2: IMutationInfo[], onlyLater: true): IFailureTransformMutationsResult | Omit<ISuccessTransformMutationsResult, 'm1Prime'>;
    /**
     * Assume `m1` has already applied to the document, we need m2Prime to be applied to the document.
     *
     * @param m1
     * @param m2
     * @returns transformed mutations of m2
     */
    private _rightInclineTransformMutations;
    private _leftInclineTransformMutations;
    transformChangesets(c1: IChangeset[], c2: IChangeset[]): ITransformChangesetsResult;
    transformChangesets(c1: IChangeset[], c2: IChangeset[], onlyLater: true): IFailureTransformChangesetsResult | Omit<ISuccessTransformChangesetsResult, 'c1Prime'>;
    transformMutationsWithChangeset(c1: IChangeset, m2: IMutationInfo[]): ITransformMutationsWithChangesetResult;
    private _logOriginTransformMutations;
    private _logCurrentTransformMutations;
}
