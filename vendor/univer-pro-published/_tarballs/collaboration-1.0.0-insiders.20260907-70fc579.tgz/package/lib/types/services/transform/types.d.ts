import type { IMutationInfo } from '@univerjs/core';
import type { IChangeset } from '../../models/changeset';
export interface ISuccessTransformMutationResult {
    m1Prime: IMutationInfo | IMutationInfo[];
    m2Prime: IMutationInfo | IMutationInfo[];
}
export interface IFailureTransformMutationResult {
    error: Error;
}
export type ITransformMutationResult = ISuccessTransformMutationResult | IFailureTransformMutationResult;
export declare function isTransformMutationFailure(result: ITransformMutationResult | Omit<ISuccessTransformMutationResult, 'm1Prime'>): result is IFailureTransformMutationResult;
export declare function isTransformMutationSuccess(result: ITransformMutationResult | Omit<ISuccessTransformMutationResult, 'm1Prime'>): result is ISuccessTransformMutationResult;
export interface IFailureInclineTransformMutationsResult {
    error: Error;
}
export type IInclineTransformMutationsResult = IMutationInfo[] | IFailureInclineTransformMutationsResult;
export declare function isInclineTransformMutationsFailure(result: IInclineTransformMutationsResult): result is IFailureInclineTransformMutationsResult;
export interface ISuccessTransformMutationsResult {
    m1Prime: IMutationInfo[];
    m2Prime: IMutationInfo[];
}
export interface IFailureTransformMutationsResult {
    error: Error;
}
export type ITransformMutationsResult = ISuccessTransformMutationsResult | IFailureTransformMutationsResult;
export declare function isTransformMutationsFailure(result: Partial<ITransformMutationsResult>): result is IFailureTransformMutationsResult;
export declare function isTransformMutationsSuccess(result: Partial<ITransformMutationsResult>): result is ISuccessTransformMutationsResult;
export interface ISuccessTransformChangesetsResult {
    c1Prime: IChangeset[];
    c2Prime: IChangeset[];
}
export interface IFailureTransformChangesetsResult {
    error: Error;
}
export type ITransformChangesetsResult = ISuccessTransformChangesetsResult | IFailureTransformChangesetsResult;
export declare function isTransformChangesetsFailure(result: Partial<ITransformChangesetsResult>): result is IFailureTransformChangesetsResult;
export declare function isTransformChangesetsSuccess(result: Partial<ITransformChangesetsResult>): result is ISuccessTransformChangesetsResult;
export interface ISuccessTransformMutationsWithChangesetResult {
    c1Prime: IChangeset;
    m2Prime: IMutationInfo[];
}
export interface IFailureTransformMutationsWithChangesetResult {
    error: Error;
}
export type ITransformMutationsWithChangesetResult = ISuccessTransformMutationsWithChangesetResult | IFailureTransformMutationsWithChangesetResult;
export declare function isTransformMutationsWithChangesetFailure(result: ITransformMutationsWithChangesetResult): result is IFailureTransformMutationsWithChangesetResult;
export declare function isTransformMutationsWithChangesetSuccess(result: ITransformMutationsWithChangesetResult): result is ISuccessTransformMutationsWithChangesetResult;
