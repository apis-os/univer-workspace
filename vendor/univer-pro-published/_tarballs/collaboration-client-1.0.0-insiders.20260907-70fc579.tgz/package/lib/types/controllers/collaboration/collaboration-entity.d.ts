import type { IDisposable, IMutationInfo, Nullable, UniverInstanceType } from '@univerjs/core';
import type { Observable } from 'rxjs';
import type { CollaborationSession } from '../../services/collaboration-session/collaboration-session';
import type { CollaborationState, ICollaborationStateHandler, PrepareTransformSelectionsHandler, SyncEditingCollabCursorHandler, TransformIMEHandler, TransformRemoteChangesetByIMECache, TransformRemoteChangesetByStateCache, TransformSelectionsHandler, TransformStateHandler } from './collaboration-state';
import { CompressMutationService, RevisionService } from '@univerjs-pro/collaboration';
import { ICommandService, ILogService, Injector, IPermissionService, IUniverInstanceService, LocaleService, RxDisposable } from '@univerjs/core';
import { DocStateChangeManagerService } from '@univerjs/docs';
import { BehaviorSubject } from 'rxjs';
import { CollaborationUIEventService } from '../../services/collaboration-ui-event/collaboration-ui-event';
import { ILocalCacheService } from '../../services/local-cache/local-cache.service';
import { SheetTransformSelectionsService } from '../../services/range-selection/sheet-transform-selections.service';
import { ISingleActiveUnitService } from '../../services/single-active-unit/single-active-unit.service';
import { CollaborationStatus } from './collaboration-state';
/**
 * Each univer document instance would map to an `CollaborationEntity` to handle collaborated editing events.
 */
export declare abstract class CollaborationEntity extends RxDisposable {
    readonly unitID: string;
    readonly session: CollaborationSession;
    protected readonly _type: UniverInstanceType;
    protected readonly _injector: Injector;
    protected readonly _compressMutationService: CompressMutationService;
    protected readonly _localeService: LocaleService;
    protected readonly _revisionService: RevisionService;
    protected readonly _eventService: CollaborationUIEventService;
    protected readonly _univerInstanceService: IUniverInstanceService;
    protected readonly _logService: ILogService;
    protected readonly _commandService: ICommandService;
    private _permissionService;
    protected readonly _singleActiveUnitService?: ISingleActiveUnitService | undefined;
    protected readonly _localCacheService?: ILocalCacheService | undefined;
    protected _state$: BehaviorSubject<Nullable<CollaborationState>>;
    readonly state$: Observable<Nullable<CollaborationState>>;
    protected _state: CollaborationState;
    get state(): CollaborationState;
    protected _collaborationPaused: boolean;
    protected _changesetSessionId: string;
    protected _changesetReqId: number;
    readonly status$: Observable<CollaborationStatus>;
    constructor(unitID: string, session: CollaborationSession, _type: UniverInstanceType, _injector: Injector, _compressMutationService: CompressMutationService, _localeService: LocaleService, _revisionService: RevisionService, _eventService: CollaborationUIEventService, _univerInstanceService: IUniverInstanceService, _logService: ILogService, _commandService: ICommandService, _permissionService: IPermissionService, _singleActiveUnitService?: ISingleActiveUnitService | undefined, _localCacheService?: ILocalCacheService | undefined);
    init(): Promise<void>;
    /**
     * Pause collaboration on the document. Remote changesets would be inserted to a queue and wait for resuming.
     * @returns a disposable which will resume collaboration when called.
     */
    pauseCollaboration(): IDisposable;
    onLocalMutation(command: IMutationInfo): void;
    private _updateState;
    protected _init(): Promise<CollaborationState>;
    /**
     * Could not transit the state twice at the same time. So we put a lock here in case of implementation fault.
     */
    private _transitionLocked;
    private _unlockTransition;
    private _lockTransition;
    protected _onLocalMutation(command: IMutationInfo): void;
    private _remoteChangesetQueue;
    private _onRemoteChangeset;
    private _exhaustRemoteChangesetQueue;
    private _applyRemoteChangeset;
    private _onRemoteACK;
    private _onRemoteRejected;
    private _onRemoteRetry;
    private _onFetchMissResult;
    private _toggleOffline;
    private _toggleOnline;
    private _createInitialState;
    protected _createHandler(): ICollaborationStateHandler;
    private _createInitialStateImpl;
    private _replayCachedMutations;
}
export interface IDocCollaborationEntityCallback {
    onPrepareTransformSelections?: PrepareTransformSelectionsHandler;
    onTransformSelections?: TransformSelectionsHandler;
    onTransformIME: TransformIMEHandler;
    onTransformState: TransformStateHandler;
    onSyncEditingCollabCursor: SyncEditingCollabCursorHandler;
    onTransformRemoteChangesetByIMECache: TransformRemoteChangesetByIMECache;
    onTransformRemoteChangesetByStateCache: TransformRemoteChangesetByStateCache;
}
export declare class DocCollaborationEntity extends CollaborationEntity {
    readonly unitID: string;
    readonly type: UniverInstanceType;
    private readonly _docStateChangeManagerService;
    private _handlerCallback;
    constructor(unitID: string, type: UniverInstanceType, session: CollaborationSession, injector: Injector, compressMutationService: CompressMutationService, localeService: LocaleService, revisionService: RevisionService, eventService: CollaborationUIEventService, univerInstanceService: IUniverInstanceService, logService: ILogService, commandService: ICommandService, permissionService: IPermissionService, _docStateChangeManagerService: DocStateChangeManagerService, singleActiveUnitService?: ISingleActiveUnitService, localCacheService?: ILocalCacheService);
    addHandlerCallback(cb: IDocCollaborationEntityCallback): void;
    dispose(): void;
    protected _createHandler(): ICollaborationStateHandler;
    protected _init(): Promise<CollaborationState>;
}
export declare class BaseCollaborationEntity extends CollaborationEntity {
    readonly unitID: string;
    readonly type: UniverInstanceType;
    constructor(unitID: string, type: UniverInstanceType, session: CollaborationSession, injector: Injector, compressMutationService: CompressMutationService, localeService: LocaleService, revisionService: RevisionService, eventService: CollaborationUIEventService, univerInstanceService: IUniverInstanceService, logService: ILogService, commandService: ICommandService, permissionService: IPermissionService, singleActiveUnitService?: ISingleActiveUnitService, localCacheService?: ILocalCacheService);
    protected _init(): Promise<CollaborationState>;
}
export declare class SheetCollaborationEntity extends CollaborationEntity {
    readonly unitID: string;
    readonly type: UniverInstanceType;
    private readonly _sheetTransformSelectionsService;
    constructor(unitID: string, type: UniverInstanceType, session: CollaborationSession, injector: Injector, compressMutationService: CompressMutationService, localeService: LocaleService, revisionService: RevisionService, _sheetTransformSelectionsService: SheetTransformSelectionsService, eventService: CollaborationUIEventService, univerInstanceService: IUniverInstanceService, logService: ILogService, commandService: ICommandService, permissionService: IPermissionService, singleActiveUnitService?: ISingleActiveUnitService, localCacheService?: ILocalCacheService);
    protected _createHandler(): ICollaborationStateHandler;
    protected _init(): Promise<CollaborationState>;
}
export declare class SlideCollaborationEntity extends CollaborationEntity {
    readonly unitID: string;
    readonly type: UniverInstanceType;
    constructor(unitID: string, type: UniverInstanceType, session: CollaborationSession, injector: Injector, compressMutationService: CompressMutationService, localeService: LocaleService, revisionService: RevisionService, eventService: CollaborationUIEventService, univerInstanceService: IUniverInstanceService, logService: ILogService, commandService: ICommandService, permissionService: IPermissionService, singleActiveUnitService?: ISingleActiveUnitService, localCacheService?: ILocalCacheService);
    protected _init(): Promise<CollaborationState>;
}
export declare class BoardCollaborationEntity extends CollaborationEntity {
    readonly unitID: string;
    readonly type: UniverInstanceType;
    constructor(unitID: string, type: UniverInstanceType, session: CollaborationSession, injector: Injector, compressMutationService: CompressMutationService, localeService: LocaleService, revisionService: RevisionService, eventService: CollaborationUIEventService, univerInstanceService: IUniverInstanceService, logService: ILogService, commandService: ICommandService, permissionService: IPermissionService, singleActiveUnitService?: ISingleActiveUnitService, localCacheService?: ILocalCacheService);
    protected _init(): Promise<CollaborationState>;
}
export declare class PdfCollaborationEntity extends CollaborationEntity {
    readonly unitID: string;
    readonly type: UniverInstanceType;
    constructor(unitID: string, type: UniverInstanceType, session: CollaborationSession, injector: Injector, compressMutationService: CompressMutationService, localeService: LocaleService, revisionService: RevisionService, eventService: CollaborationUIEventService, univerInstanceService: IUniverInstanceService, logService: ILogService, commandService: ICommandService, permissionService: IPermissionService, singleActiveUnitService?: ISingleActiveUnitService, localCacheService?: ILocalCacheService);
    protected _init(): Promise<CollaborationState>;
}
