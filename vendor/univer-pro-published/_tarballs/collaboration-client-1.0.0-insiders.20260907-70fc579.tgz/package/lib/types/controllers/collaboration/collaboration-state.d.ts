import type { IAcknowledgedChangeset, IChangeset } from '@univerjs-pro/collaboration';
import type { IMutationInfo, Nullable } from '@univerjs/core';
import type { Observable } from 'rxjs';
import type { ICollaborativeUndoRedoService } from '../../services/undoredo/collaborative-undoredo.service';
import { ITransformService, RevisionService } from '@univerjs-pro/collaboration';
import { ICommandService, IConfigService, ILogService, Injector, IPermissionService, IUniverInstanceService, LocaleService, UniverInstanceType, UserManagerService } from '@univerjs/core';
import { CollaborationUIEventService } from '../../services/collaboration-ui-event/collaboration-ui-event';
import { ILocalCacheService } from '../../services/local-cache/local-cache.service';
/** Provide both states when and after changing, so the parent could examine if state transition is correct. */
export type StateChangeHandler = (before: CollaborationState, after: CollaborationState) => void;
/** A network interface to send changeset and  */
export type SendChangesetHandler = (changeset: IChangeset) => void;
export type MissingChangesetsHandler = (params: {
    from: number;
    to: number;
}) => void;
export type TransformSelectionsHandler = (changeset: IChangeset) => void;
export interface ISelectionTransformTransaction {
    commit(): void;
    rollback(): void;
}
export type PrepareTransformSelectionsHandler = (changeset: IChangeset) => ISelectionTransformTransaction | null;
export type TransformIMEHandler = (changeset: IChangeset) => void;
export type TransformStateHandler = (changeset: IChangeset) => void;
export type SyncEditingCollabCursorHandler = (params: any) => void;
export type TransformRemoteChangesetByIMECache = (changeset: IChangeset) => IChangeset;
export type TransformRemoteChangesetByStateCache = (changeset: IChangeset) => IChangeset;
export interface ICollaborationStateHandler {
    onStateChange: StateChangeHandler;
    onSendChangeset: SendChangesetHandler;
    onMissingChangesets: MissingChangesetsHandler;
    onTransformSelections?: TransformSelectionsHandler;
    onPrepareTransformSelections?: PrepareTransformSelectionsHandler;
    onTransformIME?: TransformIMEHandler;
    onTransformState?: TransformStateHandler;
    onSyncEditingCollabCursor?: SyncEditingCollabCursorHandler;
    onTransformRemoteChangesetByIMECache?: TransformRemoteChangesetByIMECache;
    onTransformRemoteChangesetByStateCache?: TransformRemoteChangesetByStateCache;
}
export declare enum CollaborationStatus {
    NOT_COLLAB = "not_collab",
    SYNCED = "synced",
    PENDING = "pending",
    AWAITING = "awaiting",
    AWAITING_WITH_PENDING = "awaiting_with_pending",
    FETCH_MISS = "fetch_missing",
    CONFLICT = "conflict",
    OFFLINE = "offline"
}
/**
 * Use state machine to manage syncing states.
 * An explanation to how these states are transformed to each other.
 */
export declare abstract class CollaborationState {
    readonly unitID: string;
    readonly type: UniverInstanceType;
    /** State may change internally. Parent module should provide a callback to handle this event.  */
    protected readonly _handler: ICollaborationStateHandler;
    protected readonly _commandService: ICommandService;
    protected readonly _undoRedoService: ICollaborativeUndoRedoService;
    protected readonly _revisionService: RevisionService;
    protected readonly _localCacheService?: ILocalCacheService | undefined;
    abstract readonly status: CollaborationStatus;
    /** Mutations that has been sent to the server but not yet acknowledged by the server.  */
    protected _awaitingChangeset: Nullable<IChangeset>;
    /** Mutations that has not been sent to the server. */
    protected _pendingMutations: IMutationInfo[];
    constructor(unitID: string, type: UniverInstanceType, awaitingChangeset: Nullable<IChangeset>, pendingMutations: IMutationInfo[], 
    /** State may change internally. Parent module should provide a callback to handle this event.  */
    _handler: ICollaborationStateHandler, _commandService: ICommandService, _undoRedoService: ICollaborativeUndoRedoService, _revisionService: RevisionService, _localCacheService?: ILocalCacheService | undefined);
    abstract resend(): void;
    /**
     * Append a location mutation to collaboration queue.
     *
     * @param mutation a mutation that happened locally and should be broadcasted to other peers
     */
    abstract appendMutation(mutation: IMutationInfo): CollaborationState;
    /**
     * Received a changeset from the server.
     * @param changeset
     */
    abstract onRemoteChangeset(changeset: IChangeset): CollaborationState;
    /**
     * Received an acknowledgement from the server.
     */
    abstract onRemoteAck(changeset: IAcknowledgedChangeset): CollaborationState;
    /**
     * Received a rejection from the server, meaning that conflict could be resolved by the algorithm.
     */
    abstract onRemoteRej(config?: {
        isPermissionRej: boolean;
    }): CollaborationState;
    /**
     * Received a retry message from the server, meaning that some unexpected error occurred in server.
     */
    abstract onRemoteRetry(changeset: IChangeset): CollaborationState;
    abstract toggleOffline(): CollaborationState;
    abstract toggleOnline(): CollaborationState;
    /**
     * Check if there are some changesets missing. If true, the state should abort this changeset and request
     * for missing changesets. Missing changesets will later be passed to `onRemoteChangeset` method.
     *
     * @param changeset The changeset sent from the remote collaboration server.
     * @returns There is some changeset missing.
     */
    protected _checkMissing(changeset: IChangeset | IAcknowledgedChangeset): boolean;
    /** Transform undo redo mutations in the undo redo stack.  */
    protected _transformUndoredo(changeset: IChangeset): void;
    /** Transform selections by calling the selection manager service. */
    protected _transformSelections(changeset: IChangeset): void;
    protected _prepareTransformSelections(changeset: IChangeset): ISelectionTransformTransaction | null;
    protected _transformIMECache(changeset: IChangeset): void | undefined;
    protected _transformStateCache(changeset: IChangeset): void | undefined;
    protected _transformRemoteChangesetByIMECache(changeset: IChangeset): IChangeset;
    protected _transformRemoteChangesetByStateCache(changeset: IChangeset): IChangeset;
    protected _syncEditingCollabCursor(changeset: IChangeset): void;
    protected _getCurrentRevision(): number;
    protected _incrementRevisionNumber(): void;
    protected _executeRemoteChangeset(changeset: IChangeset): void;
}
/**
 * All local changesets are sent to and acknowledged by the server.
 */
export declare class SyncedState extends CollaborationState {
    private readonly _injector;
    private readonly _logService;
    private readonly _transformService;
    private readonly localCacheService?;
    readonly status = CollaborationStatus.SYNCED;
    constructor(unitID: string, type: UniverInstanceType, handler: ICollaborationStateHandler, revisionService: RevisionService, _injector: Injector, undoRedoService: ICollaborativeUndoRedoService, commandService: ICommandService, _logService: ILogService, _transformService: ITransformService, localCacheService?: ILocalCacheService | undefined);
    appendMutation(mutation: IMutationInfo): CollaborationState;
    onRemoteChangeset(changeset: IChangeset): CollaborationState;
    private _onConflict;
    onRemoteAck(changeset: IAcknowledgedChangeset): CollaborationState;
    onRemoteRej(): CollaborationState;
    onRemoteRetry(): CollaborationState;
    toggleOffline(): CollaborationState;
    toggleOnline(): CollaborationState;
    resend(): void;
    fetchMiss(): CollaborationState;
}
/**
 * Some local changes are waiting to be sent to the server. But no changesets are waiting for acknowledgement.
 *
 * You should call schedule task after you create a `PendingState`.
 */
export declare class PendingState extends CollaborationState {
    private readonly _injector;
    private readonly _userManagerService;
    private readonly _logService;
    private readonly _configService;
    private readonly _transformService;
    private readonly _univerInstanceService;
    readonly status = CollaborationStatus.PENDING;
    private _scheduleCompleteTimestamp;
    private _sendingTimer;
    constructor(unitID: string, type: UniverInstanceType, pendingMutations: IMutationInfo[], handler: ICollaborationStateHandler, _injector: Injector, _revisionService: RevisionService, _userManagerService: UserManagerService, _logService: ILogService, commandService: ICommandService, _configService: IConfigService, _transformService: ITransformService, _univerInstanceService: IUniverInstanceService, _undoRedoService: ICollaborativeUndoRedoService, _localCacheService?: ILocalCacheService);
    appendMutation(mutation: IMutationInfo): CollaborationState;
    onRemoteChangeset(changeset: IChangeset): CollaborationState;
    onRemoteAck(changeset: IAcknowledgedChangeset): CollaborationState;
    onRemoteRej(): CollaborationState;
    onRemoteRetry(): CollaborationState;
    toggleOffline(): CollaborationState;
    toggleOnline(): CollaborationState;
    private _getSendChangesetTimeout;
    resend(): void;
    private _clearScheduledTask;
    private _onConflict;
}
/**
 * All local mutations are sent to the server and waiting for acknowledgement.
 */
export declare class AwaitingState extends CollaborationState {
    private readonly _injector;
    private readonly _logService;
    private readonly _transformService;
    readonly status = CollaborationStatus.AWAITING;
    private _resendTimeout;
    private _maxTotalRetryTimeout;
    private _resendTimer;
    private _sender;
    constructor(unitID: string, type: UniverInstanceType, awaitingChangeset: IChangeset, handler: ICollaborationStateHandler, _injector: Injector, revisionService: RevisionService, commandService: ICommandService, _logService: ILogService, _transformService: ITransformService, undoRedoService: ICollaborativeUndoRedoService, localCacheService?: ILocalCacheService);
    appendMutation(mutation: IMutationInfo): CollaborationState;
    onRemoteChangeset(changeset: IChangeset): CollaborationState;
    onRemoteAck(changeset: IAcknowledgedChangeset): CollaborationState;
    onRemoteRej(config?: {
        isPermissionRej: boolean;
    }): CollaborationState;
    onRemoteRetry(changeset: IChangeset): CollaborationState;
    toggleOffline(): CollaborationState;
    toggleOnline(): CollaborationState;
    resend(): void;
    private _onConflict;
    private _resendWithTimeout;
    private _clearScheduledTask;
}
/**
 * Some local mutations are sent to the server and waiting for acknowledgement, yet still some local mutations
 * are waiting to be sent to the server.
 */
export declare class AwaitingWithPendingState extends CollaborationState {
    private readonly _injector;
    private readonly _logService;
    private readonly _transformService;
    private readonly localCacheService?;
    readonly status = CollaborationStatus.AWAITING_WITH_PENDING;
    private _resendTimeout;
    private _maxTotalRetryTimeout;
    private _resendTimer;
    private _sender;
    constructor(unitID: string, type: UniverInstanceType, awaitingChangeset: IChangeset, pendingMutations: IMutationInfo[], handler: ICollaborationStateHandler, timer: Observable<{
        timeout: number;
        reqId: number;
    }> | undefined, _injector: Injector, revisionService: RevisionService, commandService: ICommandService, _logService: ILogService, _transformService: ITransformService, undoRedoService: ICollaborativeUndoRedoService, localCacheService?: ILocalCacheService | undefined);
    appendMutation(mutation: IMutationInfo): CollaborationState;
    onRemoteChangeset(changeset: IChangeset): CollaborationState;
    onRemoteAck(changeset: IAcknowledgedChangeset): CollaborationState;
    onRemoteRej(config?: {
        isPermissionRej: boolean;
    }): CollaborationState;
    onRemoteRetry(changeset: IChangeset): CollaborationState;
    toggleOffline(): CollaborationState;
    toggleOnline(): CollaborationState;
    resend(): void;
    private _onConflict;
    private _resendWithTimeout;
    private _clearScheduledTask;
}
/**
 * This state is special for handling collaboration conflicts.
 *
 * `ConflictState` is a dead end state. It cannot transit to any other state. User could only reload the page to
 * reload the document.
 */
export declare class ConflictState extends CollaborationState {
    private _isPermissionRej;
    private readonly _permissionService;
    private readonly _localeService;
    private readonly _collaborationUIEventService;
    private readonly localCacheService?;
    readonly status = CollaborationStatus.CONFLICT;
    constructor(unitID: string, type: UniverInstanceType, awaitingChangeset: Nullable<IChangeset>, pendingMutations: IMutationInfo[], handler: ICollaborationStateHandler, _isPermissionRej: boolean | undefined, _permissionService: IPermissionService, commandService: ICommandService, undoRedoService: ICollaborativeUndoRedoService, revisionService: RevisionService, _localeService: LocaleService, _collaborationUIEventService: CollaborationUIEventService, localCacheService?: ILocalCacheService | undefined);
    appendMutation(): CollaborationState;
    onRemoteChangeset(): CollaborationState;
    onRemoteAck(): CollaborationState;
    onRemoteRej(): CollaborationState;
    onRemoteRetry(): CollaborationState;
    toggleOffline(): CollaborationState;
    toggleOnline(): CollaborationState;
    resend(): void;
    private _clearLocalCache;
    private _showConflictNotification;
    private _disableEditing;
}
export declare class OfflineState extends CollaborationState {
    private readonly _injector;
    readonly status = CollaborationStatus.OFFLINE;
    constructor(unitID: string, type: UniverInstanceType, awaitingChangeset: Nullable<IChangeset>, pendingMutations: IMutationInfo[], handler: ICollaborationStateHandler, _injector: Injector, revisionService: RevisionService, commandService: ICommandService, undoRedoService: ICollaborativeUndoRedoService, localCacheService?: ILocalCacheService);
    appendMutation(mutation: IMutationInfo): CollaborationState;
    onRemoteChangeset(_changeset: IChangeset): CollaborationState;
    onRemoteAck(): CollaborationState;
    onRemoteRej(): CollaborationState;
    onRemoteRetry(): CollaborationState;
    toggleOffline(): CollaborationState;
    toggleOnline(): CollaborationState;
    resend(): void;
}
/**
 * When the client is trying to fetch missed changesets:
 *
 * 1. local changesets would not be send to the server until the missed changesets are fetched
 * 2. remote changesets would not be applied util the missed changesets are fetched and applied
 */
export declare class FetchingMissState extends CollaborationState {
    /**
     * The awaiting changeset may have been acknowledged while missing changesets are fetched.
     * Keep the changeset in `_awaitingChangeset` for transform and sid/reqId de-duplication, and store only
     * the acknowledged server revision here.
     */
    private _acknowledgedAwaitingRevision;
    private _queuedRemoteChangesets;
    private readonly _injector;
    private readonly _logService;
    private readonly _transformService;
    private readonly localCacheService?;
    readonly status = CollaborationStatus.FETCH_MISS;
    constructor(unitID: string, type: UniverInstanceType, awaitingChangeset: Nullable<IChangeset>, pendingMutations: IMutationInfo[], 
    /**
     * The awaiting changeset may have been acknowledged while missing changesets are fetched.
     * Keep the changeset in `_awaitingChangeset` for transform and sid/reqId de-duplication, and store only
     * the acknowledged server revision here.
     */
    _acknowledgedAwaitingRevision: Nullable<number>, _queuedRemoteChangesets: IChangeset[], handler: ICollaborationStateHandler, _injector: Injector, revisionService: RevisionService, _logService: ILogService, commandService: ICommandService, undoRedoService: ICollaborativeUndoRedoService, _transformService: ITransformService, localCacheService?: ILocalCacheService | undefined);
    onMissedChangesetFetched(changesets: IChangeset[]): CollaborationState;
    private _handleRemoteChangesets;
    private _transformAndApplyRemoteChangeset;
    private _acknowledgeAwaitingIfReady;
    private _acknowledgeAwaiting;
    private _isEchoedAwaitingChangeset;
    resend(): void;
    appendMutation(mutation: IMutationInfo<object>): CollaborationState;
    onRemoteChangeset(changeset: IChangeset): CollaborationState;
    onRemoteAck(changeset: IAcknowledgedChangeset): CollaborationState;
    onRemoteRej(config?: {
        isPermissionRej: boolean;
    }): CollaborationState;
    onRemoteRetry(): CollaborationState;
    toggleOffline(): CollaborationState;
    toggleOnline(): CollaborationState;
    private _onConflict;
}
export declare function createOnlineState(injector: Injector, unitID: string, type: UniverInstanceType, awaitingChangeset: Nullable<IChangeset>, mutations: IMutationInfo[], handler: ICollaborationStateHandler): SyncedState | PendingState | AwaitingState | AwaitingWithPendingState;
