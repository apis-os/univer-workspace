import type { Nullable } from '@univerjs/core';
import type { Observable } from 'rxjs';
import type { CollaborationEntity } from './collaboration-entity';
import { IConfigService, Injector, IUniverInstanceService, RxDisposable } from '@univerjs/core';
import { CollaborationSessionService } from '../../services/collaboration-session/collaboration-session.service';
export declare class CollaborationController extends RxDisposable {
    private readonly _injector;
    private readonly _collabSessionService;
    private readonly _configService;
    private readonly _univerInstanceService;
    private readonly _entities;
    private readonly _entityInit$;
    readonly entityInit$: Observable<CollaborationEntity>;
    constructor(_injector: Injector, _collabSessionService: CollaborationSessionService, _configService: IConfigService, _univerInstanceService: IUniverInstanceService);
    dispose(): void;
    getCollabEntity(id: string): Nullable<CollaborationEntity>;
    getCollabEntity$(id: string): Observable<CollaborationEntity>;
    readyForCollab(id: string): Promise<void>;
    private _init;
    /**
     * Start collaboration on a document.
     *
     * @param unitID ID of the document to start collaboration.
     * @returns A disposable to stop collaboration.
     */
    private _startCollaboration;
    private _getCtorByUniverInstanceType;
}
