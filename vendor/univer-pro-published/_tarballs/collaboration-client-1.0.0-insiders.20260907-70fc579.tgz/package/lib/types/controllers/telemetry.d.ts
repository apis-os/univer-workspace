import type { IMutationInfo, UniverInstanceType } from '@univerjs/core';
export declare const TELEMETRY_COLLABORATION_NEW_CHANGESET = "collaboration_new_changeset";
export interface INewChangesetTelemetryInfo {
    startTime: number;
    stopTime: number;
    duration: number;
    size: number;
    type: UniverInstanceType;
    unitId: string;
}
export declare function summaryChangesetSize(mutations: IMutationInfo[]): number;
