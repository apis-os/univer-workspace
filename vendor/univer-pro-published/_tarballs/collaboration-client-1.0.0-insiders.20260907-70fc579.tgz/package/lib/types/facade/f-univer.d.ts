import type { Injector, UnitModel, UniverInstanceType } from '@univerjs/core';
import { FUniver } from '@univerjs/core/facade';
import { FCollaboration } from './f-collaboration';
/**
 * @ignore
 */
export interface IFUniverCollaborationClientMixin {
    /**
     * Get the collaboration instance to manage the collaboration issue of the current univer.
     * @returns The collaboration instance.
     *
     * @example
     * ```typescript
     * const collaboration = univerAPI.getCollaboration();
     * ```
     */
    getCollaboration(): FCollaboration;
    /**
     * Load the server unit by the given unit id and unit type.
     * @param {string} unitId The unit id.
     * @param {UniverInstanceType} unitType The unit type.
     * @param {string} [subUnitId] The sub unit id.
     * @returns {Promise<UnitModel | null>} The promise with the unit model.
     *
     * @example
     * ```typescript
     * const unitModel = await univerAPI.loadServerUnit('unitId', univerAPI.Enum.UniverInstanceType.UNIVER_SHEET);
     * console.log(unitModel, unitModel?.getSnapshot());
     * ```
     */
    loadServerUnit(unitId: string, unitType: UniverInstanceType, subUnitId?: string): Promise<UnitModel | null>;
    /**
     * Load the server unit by the given unit id, unit type and revision.
     * @param unitId The unit id.
     * @param unitType The unit type.
     * @param rev The revision number.
     * @returns The promise with the unit model.
     *
     * @example
     * ```typescript
     * const unitModel = await univerAPI.loadServerUnitOfRevision('unitId', univerAPI.Enum.UniverInstanceType.UNIVER_SHEET, 1);
     * console.log(unitModel, unitModel?.getSnapshot());
     * ```
     */
    loadServerUnitOfRevision(unitId: string, unitType: UniverInstanceType, rev: number): Promise<UnitModel | null>;
}
export declare class FUniverCollaborationClientMixin extends FUniver implements IFUniverCollaborationClientMixin {
    _initialize(injector: Injector): void;
    getCollaboration(): FCollaboration;
    loadServerUnit(unitId: string, unitType: UniverInstanceType, subUnitId?: string): Promise<UnitModel | null>;
    loadServerUnitOfRevision(unitId: string, unitType: UniverInstanceType, rev: number): Promise<UnitModel | null>;
}
/**
 * @ignore
 */
declare module '@univerjs/core/facade' {
    interface FUniver extends IFUniverCollaborationClientMixin {
    }
}
