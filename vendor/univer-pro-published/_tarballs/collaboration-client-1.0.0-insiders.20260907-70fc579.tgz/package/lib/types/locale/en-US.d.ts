declare const locale: {
    'collaboration-client': {
        collabClient: {
            tooltip: {
                reconnect: string;
            };
        };
        collabStatus: {
            fetchMiss: string;
            conflict: string;
            notCollab: string;
            synced: string;
            syncing: string;
            offline: string;
        };
        session: {
            'connection-failed': string;
            'will-retry': string;
            'room-full': string;
            'join-failed': string;
            'room-not-exists': string;
            'room-permission-denied': string;
            'room-cnt-exceeds': string;
            'collaboration-timeout': string;
        };
        conflict: {
            title: string;
            content: string;
        };
        permission: {
            title: string;
            content: string;
        };
        collaboration: {
            'single-unit': {
                warning: string;
            };
            closeRoom: string;
        };
        auth: {
            needGotoLoginAlert: string;
        };
    };
};
export default locale;
