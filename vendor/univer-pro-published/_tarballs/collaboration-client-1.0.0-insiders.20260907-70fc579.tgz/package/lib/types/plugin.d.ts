import type { IUniverCollaborationClientConfig } from './config/config';
import { IConfigService, ILogService, Injector, Plugin } from '@univerjs/core';
export declare class UniverCollaborationClientPlugin extends Plugin {
    private readonly _config;
    private readonly _logService;
    protected _injector: Injector;
    private readonly _configService;
    static pluginName: string;
    static packageName: string;
    static version: string;
    constructor(_config: Partial<IUniverCollaborationClientConfig> | undefined, _logService: ILogService, _injector: Injector, _configService: IConfigService);
    onStarting(): void;
    private _registerDependencies;
    private _initDependencies;
}
