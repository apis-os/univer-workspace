import type { ICollaborationEvent } from '@univerjs-pro/collaboration';
import type { IDisposable, Nullable } from '@univerjs/core';
import type { Observable } from 'rxjs';
import type { ICollaborationSocket } from '../socket/collaboration-socket.service';
import type { ICollaborationSessionIdentity } from './collaboration-client-adapter';
import { IConfigService, ILogService, RxDisposable } from '@univerjs/core';
import { ITelemetryService } from '@univerjs/telemetry';
import { CollaborationUIEventService } from '../collaboration-ui-event/collaboration-ui-event';
import { CommentService } from '../comment/comment.service';
import { MemberService } from '../member/member.service';
export declare enum SessionStatus {
    IDLE = 0,
    JOINING = 1,
    OFFLINE = 2,
    ONLINE = 3
}
export declare const FailedReason: {
    2: string;
    1001: string;
    1002: string;
    1003: string;
    1004: string;
};
/**
 * The data structure to represent a collaboration session. It also manages the collaborator's identity.
 *
 * A collaboration session maps one local unit to one collaboration target.
 */
export declare class CollaborationSession extends RxDisposable implements IDisposable {
    private readonly _identity;
    private readonly _logService;
    private readonly _configService;
    private readonly _memberService;
    private readonly _commentService;
    private readonly _collaborationUIEventService;
    private readonly _telemetryService?;
    private readonly _sessionStatus$;
    readonly sessionStatus$: Observable<SessionStatus>;
    get sessionStatus(): SessionStatus;
    private readonly _event$;
    readonly event$: Observable<ICollaborationEvent>;
    private _socket;
    private _socketMessageSubscription;
    constructor(_identity: ICollaborationSessionIdentity, socket$: Observable<Nullable<ICollaborationSocket>>, _logService: ILogService, _configService: IConfigService, _memberService: MemberService, _commentService: CommentService, _collaborationUIEventService: CollaborationUIEventService, _telemetryService?: ITelemetryService | undefined);
    getMemberID(): string | null;
    dispose(): void;
    close(): void;
    private _onCombEvent;
    private _joinRoom;
    private _onJoinRoomEvent;
    private _onRecvEvent;
    private _onUserJoin;
    private _onUserLeave;
    /**
     * Send event to the collaboration server.
     */
    send(event: ICollaborationEvent, _unitID: string): Promise<void>;
    private _collaborationTimeoutTimer;
    private _scheduleCollaborationTimeoutTimer;
    private _clearCollaborationTimeoutTimer;
    private _shouldReportTelemetry;
    private _telemetryInfo;
    private _startTelemetryCollaborationNewChangeset;
    private _stopTelemetryCollaborationNewChangeset;
    private _throwTelemetryCollaborationNewChangeset;
}
