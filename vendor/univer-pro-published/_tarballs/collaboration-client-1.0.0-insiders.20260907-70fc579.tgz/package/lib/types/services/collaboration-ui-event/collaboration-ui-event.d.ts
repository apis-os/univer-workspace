export interface ICollaborationUIEvent {
    id: CollaborationUIEventId;
    data?: string;
}
export declare enum CollaborationUIEventId {
    OTHER_CLIENT_EDITING = "OTHER_CLIENT_EDITING",
    PERMISSION_DENIED = "PERMISSION_DENIED",
    CONFLICT = "CONFLICT",
    CLOSE_ROOM = "CLOSE_ROOM",
    JOIN_ROOM_FAILED = "JOIN_ROOM_FAILED",
    SOCKET_FAILED_RETRY = "SOCKET_FAILED_RETRY",
    SOCKET_FAILED = "SOCKET_FAILED",
    SUBMIT_CHANGESET_TIMEOUT = "SUBMIT_CHANGESET_TIMEOUT"
}
export declare class CollaborationUIEventService {
    private readonly _event$;
    readonly event$: import("rxjs").Observable<ICollaborationUIEvent>;
    emitEvent(event: ICollaborationUIEvent): void;
}
