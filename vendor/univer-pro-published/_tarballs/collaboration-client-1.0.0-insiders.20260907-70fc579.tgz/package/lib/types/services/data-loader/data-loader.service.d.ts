import type { UnitModel } from '@univerjs/core';
import { SnapshotService } from '@univerjs-pro/collaboration';
import { ILogService, RxDisposable, UniverInstanceType } from '@univerjs/core';
import { ILocalCacheService } from '../local-cache/local-cache.service';
export interface IUnitInfo {
    unitId: string;
    type: UniverInstanceType;
    subUnitId?: string;
}
/**
 * This service provides a way to load data from the server and initialize the Univer instance.
 */
export declare class DataLoaderService extends RxDisposable {
    private readonly _logService;
    private readonly _snapshotService;
    private readonly _localCacheService?;
    private readonly _unitInfo$;
    private readonly _unitLoaded$;
    readonly unitInfo$: import("rxjs").Observable<IUnitInfo | null>;
    readonly unitLoaded$: import("rxjs").Observable<UnitModel<object, UniverInstanceType>>;
    constructor(_logService: ILogService, _snapshotService: SnapshotService, _localCacheService?: ILocalCacheService | undefined);
    dispose(): void;
    loadUnitOfRevision(unitId: string, type: UniverInstanceType, rev: number, subUnitId?: string): Promise<UnitModel | null>;
    loadUnit(unitId: string, type: UniverInstanceType, subUnitId?: string): Promise<UnitModel | null>;
}
