import type { IImageIoService, IImageIoServiceParam, Nullable } from '@univerjs/core';
import type { IError } from '@univerjs/protocol';
import type { Observable } from 'rxjs';
import { IConfigService, ImageSourceType, IUniverInstanceService } from '@univerjs/core';
import { HTTPService } from '@univerjs/network';
export interface ISignUrlResponse {
    error: IError | undefined;
    url: string;
}
export declare class CollaborationImageIoService implements IImageIoService {
    private readonly _httpService;
    private readonly _configService;
    private readonly _univerInstanceService;
    private _waitCount;
    private _change$;
    change$: Observable<number>;
    constructor(_httpService: HTTPService, _configService: IConfigService, _univerInstanceService: IUniverInstanceService);
    setWaitCount(count: number): void;
    private _imageSourceCache;
    getImageSourceCache(source: string, imageSourceType: ImageSourceType): HTMLImageElement | undefined;
    addImageSourceCache(source: string, imageSourceType: ImageSourceType, imageSource: Nullable<HTMLImageElement>): void;
    getImage(imageId: string): Promise<string>;
    saveImage(imageFile: File): Promise<Nullable<IImageIoServiceParam>>;
    private _getUploadFileURL;
    private _getSignURL;
    private _getDownloadEndpointURL;
    private _replaceFileID;
    private _decreaseWaiting;
}
