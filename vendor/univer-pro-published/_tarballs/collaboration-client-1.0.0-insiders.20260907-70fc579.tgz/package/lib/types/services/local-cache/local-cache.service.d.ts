import type { IChangeset } from '@univerjs-pro/collaboration';
import type { IMutationInfo, Nullable, UniverInstanceType } from '@univerjs/core';
export interface IUnitCacheData {
    unitID: string;
    type: UniverInstanceType;
    rev: number;
    awaitingChangeset: Nullable<IChangeset>;
    mutations: IMutationInfo[];
}
export interface ILocalCacheService {
    loadOfflineData(unitID: string): Promise<Nullable<IUnitCacheData>>;
    saveOfflineData(unitID: string, data: IUnitCacheData): Promise<boolean>;
    backupOfflineData?(unitID: string, reason: string): Promise<void>;
    updateOfflineData(unitID: string, type: UniverInstanceType, awaitingChangeset: Nullable<IChangeset>, pendingMutations: IMutationInfo[]): void;
    disableLocalCache(): void;
    enableLocalCache(): void;
    exhaustSavingTask(): Promise<void>;
    saveTaskMap: Map<string, number>;
}
export declare const ILocalCacheService: import("@wendellhu/redi").IdentifierDecorator<ILocalCacheService>;
export declare function getLocalCacheKey(unitID: string): string;
