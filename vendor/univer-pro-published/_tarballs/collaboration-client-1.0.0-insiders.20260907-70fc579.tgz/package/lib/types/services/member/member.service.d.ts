import type { IMember } from '@univerjs/protocol';
import type { Observable } from 'rxjs';
import { Disposable, IUniverInstanceService } from '@univerjs/core';
/**
 * This services manages members is each rooms.
 */
export declare class MemberService extends Disposable {
    private readonly _univerInstanceService;
    private _roomMembers;
    private readonly _roomCreated$;
    constructor(_univerInstanceService: IUniverInstanceService);
    waitForRoom$(unitId: string): Observable<RoomMember>;
    /**
     * Update a member in a room(unit).
     * @param roomID i.e. unitID.
     * @param member member object to be updated.
     */
    updateMember(roomID: string, member: IMember): void;
    /**
     * Remove a member from a room(unit).
     * @param roomID i.e. unitID.
     * @param memberID memberID of the member to be removed.
     */
    removeMember(roomID: string, memberID: string): void;
    /**
     * Get RoomMember for a unit.
     * @param roomID which is same with unitId.
     * @returns RoomMember which is a object that manages members in a single room.
     */
    getRoom(roomID: string): RoomMember | undefined;
    /**
     * Get a member in a room(unit).
     * @param roomID i.e. unitID.
     * @param memberID memberID of the member to be retrieved.
     * @returns member object.
     */
    getMember(roomID: string, memberID: string): IMember | undefined;
    private _removeRoom;
    dispose(): void;
}
/**
 * This class manages members is a single room.
 */
export declare class RoomMember extends Disposable {
    private readonly _members;
    private readonly _members$;
    readonly members$: Observable<Map<string, IMember>>;
    dispose(): void;
    /**
     * Update a member in the room(unit).
     * @param member member object to be updated.
     */
    updateMember(member: IMember): void;
    /**
     * Remove a member from the room(unit).
     * @param memberID memberID of the member to be removed.
     */
    removeMember(memberID: string): void;
    /**
     * Get a member by memberID.
     * @param memberID
     * @returns member object.
     */
    getMember(memberID: string): IMember | undefined;
    /**
     * Get all members in the room(unit).
     * @returns member object array.
     */
    getAllMembers(): IMember[];
    private _emitMembers;
}
