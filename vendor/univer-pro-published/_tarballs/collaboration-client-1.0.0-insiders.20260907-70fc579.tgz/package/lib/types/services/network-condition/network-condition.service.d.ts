import type { Observable } from 'rxjs';
export interface INetworkConditionService {
    online$: Observable<boolean>;
    online: boolean;
}
export declare const INetworkConditionService: import("@wendellhu/redi").IdentifierDecorator<INetworkConditionService>;
