import type { IChangeset } from '@univerjs-pro/collaboration';
import { ITransformService } from '@univerjs-pro/collaboration';
import { Injector, IUniverInstanceService } from '@univerjs/core';
export declare function extractTargetFromFirstChangeset(changeset: IChangeset): {
    unitId: string;
    subUnitId: string | null;
};
export declare class SheetTransformSelectionsService {
    private readonly _injector;
    private readonly _transformService;
    private readonly _instanceService;
    constructor(_injector: Injector, _transformService: ITransformService, _instanceService: IUniverInstanceService);
    transformSelections(changeset: IChangeset): void;
}
