import type { Observable } from 'rxjs';
/**
 * It is not recommended to open multiple units in different browser tabs at the same time,
 * especially when the there is not access to the internet. There is a great chance of loosing
 * offline data! So we should make there is only one active unit at a time.
 */
export declare const ISingleActiveUnitService: import("@wendellhu/redi").IdentifierDecorator<ISingleActiveUnitService>;
export interface ISingleActiveUnitService {
    editingUnit: (unitID: string) => void;
    getUnitStatus$: (unitID: string) => Observable<UnitStatus>;
}
export declare enum UnitStatus {
    NO_OTHER_CLIENTS_EDITING = 0,
    OTHER_CLIENTS_EDITING = 1
}
