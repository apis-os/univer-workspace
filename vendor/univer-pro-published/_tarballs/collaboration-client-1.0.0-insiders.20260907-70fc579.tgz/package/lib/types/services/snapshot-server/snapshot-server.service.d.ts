import type { ILogContext, ISnapshotServerService } from '@univerjs-pro/collaboration';
import type { ICopyFileMetaResponse, IFetchMissingChangesetsRequest, IFetchMissingChangesetsResponse, IGetDeserializedSheetBlockResponse, IGetLatestCsReqIdBySidResponse, IGetResourcesRequest, IGetResourcesResponse, IGetSheetBlockRequest, IGetSheetBlockResponse, IGetUnitOnRevRequest, IGetUnitOnRevResponse, ISaveChangesetResponse, ISaveSheetBlockResponse, ISaveSnapshotResponse } from '@univerjs/protocol';
import { IConfigService } from '@univerjs/core';
import { HTTPService } from '@univerjs/network';
export declare class SnapshotServerOverHTTPService implements ISnapshotServerService {
    private readonly _configService;
    private readonly _httpService;
    constructor(_configService: IConfigService, _httpService: HTTPService);
    getUnitOnRev(_context: ILogContext, params: IGetUnitOnRevRequest): Promise<IGetUnitOnRevResponse>;
    getSheetBlock(_context: ILogContext, params: IGetSheetBlockRequest): Promise<IGetSheetBlockResponse>;
    getDeserializedSheetBlock(_context: ILogContext, params: IGetSheetBlockRequest): Promise<IGetDeserializedSheetBlockResponse>;
    fetchMissingChangesets(_context: ILogContext, params: IFetchMissingChangesetsRequest): Promise<IFetchMissingChangesetsResponse>;
    /**
     * Get the prefix of the snapshot server API.
     * @returns The prefix of the snapshot server API.
     */
    getSnapshotAPIPath(): string;
    private _getAPIPrefix;
    getResourcesRequest(_context: ILogContext, params: IGetResourcesRequest): Promise<IGetResourcesResponse>;
    saveSnapshot(): Promise<ISaveSnapshotResponse>;
    updateSnapshot(): Promise<ISaveSnapshotResponse>;
    saveSheetBlock(): Promise<ISaveSheetBlockResponse>;
    saveChangeset(): Promise<ISaveChangesetResponse>;
    copyFileMeta(): Promise<ICopyFileMetaResponse>;
    getLatestCsReqIdBySid(): Promise<IGetLatestCsReqIdBySidResponse>;
}
