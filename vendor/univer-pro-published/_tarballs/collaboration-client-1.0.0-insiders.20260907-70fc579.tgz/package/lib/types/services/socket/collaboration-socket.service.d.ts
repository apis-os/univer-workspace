import type { ICombRequestEvent, ICombResponseEvent, IFetchingMissEvent, ISubmitChangesetEvent } from '@univerjs-pro/collaboration';
import type { Nullable } from '@univerjs/core';
import type { ISocket } from '@univerjs/network';
import type { IChangeset } from '@univerjs/protocol';
import type { Observable } from 'rxjs';
import { ISnapshotServerService } from '@univerjs-pro/collaboration';
import { Disposable, IConfigService, ILogService, Injector } from '@univerjs/core';
import { HTTPService } from '@univerjs/network';
/**
 * A special wrapper around of the original {@link ISocket} implementation to
 * for collaboration.
 */
export interface ICollaborationSocket extends Pick<ISocket, 'open$' | 'error$' | 'close$'> {
    memberID: string;
    message$: Observable<ICombResponseEvent>;
    send: (event: ICombRequestEvent) => void;
    close: () => void;
}
/**
 * This service provides a method to open a socket be used to communicate with the collaboration server.
 * Different environments may have different implementations of this service, because of the different
 * authentication methods.
 */
export interface ICollaborationSocketService {
    createSocket: (url: string) => Promise<Nullable<ICollaborationSocket>>;
}
export declare const ICollaborationSocketService: import("@wendellhu/redi").IdentifierDecorator<ICollaborationSocketService>;
export declare abstract class CollaborationSocketService extends Disposable implements ICollaborationSocketService {
    protected readonly _injector: Injector;
    protected readonly _httpService: HTTPService;
    protected readonly _configService: IConfigService;
    protected readonly _logService: ILogService;
    protected readonly _snapshotServerService: ISnapshotServerService;
    constructor(_injector: Injector, _httpService: HTTPService, _configService: IConfigService, _logService: ILogService, _snapshotServerService: ISnapshotServerService);
    abstract createSocket(url: string): Promise<Nullable<ICollaborationSocket>>;
    /**
     * Create a socket that would connect to the remote collaboration server. It would throw an error when the socket cannot be created.
     *
     * @param URL The URL of the remote server.
     */
    protected _doCreateSocket(URL: string): Nullable<ICollaborationSocket>;
    protected _submitChangeset(socket: ICollaborationSocket, event: ISubmitChangesetEvent): Promise<void>;
    protected _fetchMissChangesets(event: IFetchingMissEvent): Promise<IChangeset[]>;
}
