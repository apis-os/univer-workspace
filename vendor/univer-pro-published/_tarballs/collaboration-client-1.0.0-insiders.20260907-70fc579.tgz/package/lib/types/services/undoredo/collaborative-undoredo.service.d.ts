import type { IChangeset } from '@univerjs-pro/collaboration';
import type { IUndoRedoService } from '@univerjs/core';
import { ITransformService } from '@univerjs-pro/collaboration';
import { ICommandService, IConfigService, IContextService, ILogService, IUniverInstanceService, LocalUndoRedoService } from '@univerjs/core';
/**
 * `LocalUndoRedoService` cannot transform mutations in the undo redo stack under collaboration conditions.
 */
export interface ICollaborativeUndoRedoService extends IUndoRedoService {
    transformUndoRedo: (unitID: string, changeset: IChangeset) => void;
}
export declare class CollaborativeUndoRedoService extends LocalUndoRedoService implements ICollaborativeUndoRedoService {
    private readonly _transformService;
    private readonly _logService;
    constructor(_currentUniverSheet: IUniverInstanceService, _commandService: ICommandService, _contextService: IContextService, _configService: IConfigService, _transformService: ITransformService, _logService: ILogService);
    transformUndoRedo(unitID: string, changesets: IChangeset): void;
    private _clearUndo;
    private _clearRedo;
    private _substituteUndoStack;
    private _substituteRedoStack;
    private _transformStack;
}
