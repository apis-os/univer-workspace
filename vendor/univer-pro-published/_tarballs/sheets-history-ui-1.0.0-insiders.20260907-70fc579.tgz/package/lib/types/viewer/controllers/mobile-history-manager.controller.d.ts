import { Disposable, IConfigService, Injector, IPermissionService, LocaleService } from '@univerjs/core';
import { IMessageService, IUIPartsService } from '@univerjs/ui';
import { HistoryManagerService } from '../services/history-manager.service';
export declare class MobileHistoryManagerController extends Disposable {
    private readonly _permissionService;
    private readonly _uiPartsService;
    private readonly _messageService;
    private readonly _localeService;
    private readonly _historyManagerService;
    private readonly _injector;
    private readonly _configService;
    constructor(_permissionService: IPermissionService, _uiPartsService: IUIPartsService, _messageService: IMessageService, _localeService: LocaleService, _historyManagerService: HistoryManagerService, _injector: Injector, _configService: IConfigService);
    private _init;
    private _registerHeader;
    private _registerLoadingMask;
}
