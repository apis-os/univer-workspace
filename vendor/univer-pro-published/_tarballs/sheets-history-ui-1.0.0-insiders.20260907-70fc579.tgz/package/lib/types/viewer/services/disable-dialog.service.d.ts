import type { IDisposable } from '@univerjs/core';
import type { IDialogPartMethodOptions, IDialogService } from '@univerjs/ui';
import type { Observable } from 'rxjs';
import { Disposable } from '@univerjs/core';
import { Subject } from 'rxjs';
export declare class DisableDialogService extends Disposable implements IDialogService {
    protected readonly _dialogOptions$: Subject<IDialogPartMethodOptions[]>;
    constructor();
    open(): IDisposable;
    close(): void;
    closeAll(_expectIds?: string[]): void;
    getDialogs$(): Observable<IDialogPartMethodOptions[]>;
}
