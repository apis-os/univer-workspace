import type { HistoryOrigin, IHistoryCreator, IHistoryVersion, IUser } from './history-fetch.service';
import { Disposable, IConfirmService, ILogService, LocaleService } from '@univerjs/core';
import { IMessageService } from '@univerjs/ui';
import { HistoryFetchService } from './history-fetch.service';
export declare enum HistoryModeStatus {
    Entered = "entered",
    Exited = "exited",
    Error = "error"
}
export declare enum LoadingState {
    Init = "init",
    Loading = "loading",
    Loaded = "loaded",
    Error = "error"
}
export declare const VIRTUAL_VERSION_NOW = "VIRTUAL_VERSION_NOW";
export declare class HistoryManagerService extends Disposable {
    private readonly _messageService;
    private readonly _confirmService;
    private readonly _logService;
    private readonly _localeService;
    private readonly _historyFetchService;
    private _versions$;
    readonly versions$: import("rxjs").Observable<IHistoryVersion[]>;
    private _currentVersion$;
    readonly currentVersion$: import("rxjs").Observable<string>;
    private _status$;
    readonly status$: import("rxjs").Observable<HistoryModeStatus>;
    private _revertRevision$;
    readonly revertRevision$: import("rxjs").Observable<number>;
    private _unitId$;
    readonly unitId$: import("rxjs").Observable<string | null>;
    private _fetching$;
    readonly fetching$: import("rxjs").Observable<boolean>;
    private _creators$;
    readonly creators$: import("rxjs").Observable<IHistoryCreator[]>;
    private _openPanel$;
    readonly openPanel$: import("rxjs").Observable<boolean>;
    private _detailVersionsMap;
    private _setFetching;
    get fetching(): boolean;
    private _loadingState$;
    readonly loadingState$: import("rxjs").Observable<LoadingState>;
    private _lastLabel;
    private _hasMore;
    private _members;
    private _canRevert;
    private _loadParams;
    private _unitCurrentVersionMap;
    constructor(_messageService: IMessageService, _confirmService: IConfirmService, _logService: ILogService, _localeService: LocaleService, _historyFetchService: HistoryFetchService);
    triggerLoadVersions(unitId: string, canRevert: boolean): Promise<void>;
    triggerCustomVersions(unitId: string, canRevert: boolean, param: {
        hasMore: boolean;
        lastLabel: string;
        versions: IHistoryVersion[];
        members: Record<string, IUser>;
    }): void;
    loadInitialVersions(unitId: string, params?: {
        userIds?: string[];
        origin?: HistoryOrigin;
    }): Promise<void>;
    loadMoreVersions(): Promise<boolean>;
    loadHistoryCreatorList(): Promise<void>;
    triggerLoadSheet(versionId: string): Promise<void>;
    triggerRevert(id?: string): Promise<void>;
    private _updateVersions;
    getCurrentVersion(): IHistoryVersion | undefined;
    private _setVersions;
    getVersion(id: string): IHistoryVersion | undefined;
    registerDetailVersion(version: IHistoryVersion): void;
    getCurrentUnitCurrentVersion(): number | undefined;
    getSelectedVersionIsCurrentVersion(): boolean;
    getSelectedVersionCanRevert(): boolean;
    getMember(id: string): IUser | undefined;
    exitHistoryMode(): void;
    set status(value: HistoryModeStatus);
    get status(): HistoryModeStatus;
    selectVersion(value: string): void;
    get currentVersion(): string;
    set unitId(value: string | null);
    get unitId(): string | null;
    get canRevert(): boolean;
    get loadingState(): LoadingState;
}
