import type { ICommand } from '@univerjs/core';
export declare const PRINT_GRID_SIDEBAR_COMPONENT = "PRINT_GRID_SIDEBAR_COMPONENT";
export declare const OpenPrintGridSidebarOperation: ICommand;
export declare const ClosePrintGridSidebarOperation: ICommand;
