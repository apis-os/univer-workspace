import type { IPrintMargin, PrintAlign, PrintDirection, PrintPaperMargin, PrintScale } from '@univerjs-pro/print';
import type { IRange, Nullable, PaperType } from '@univerjs/core';
import type { IWatermarkConfigWithType } from '@univerjs/engine-render';
/**
 * Defines the area of the spreadsheet to be printed
 */
export declare enum PrintArea {
    /** Print only the current active sheet */
    CurrentSheet = "CurrentSheet",
    /** Print the entire workbook */
    workbook = "Workbook",
    /** Print only the current selected range */
    CurrentSelection = "CurrentSelection",
    /** Print all selected ranges across sheets */
    AllSelection = "AllSelection"
}
/**
 * Defines the available placeholders for header and footer content
 */
export declare enum PrintHeaderFooter {
    /** Insert current page size information */
    PageSize = "PageSize",
    /** Insert workbook name */
    WorkbookTitle = "WorkbookTitle",
    /** Insert worksheet name */
    WorksheetTitle = "WorksheetTitle",
    /** Insert current date */
    Date = "Date",
    /** Insert current time */
    Time = "Time"
}
/**
 * Configuration interface for header and footer content positioning
 */
export interface IPrintHeaderFooter {
    /** Content to display in the top-left section */
    topLeft: string;
    /** Content to display in the top-center section */
    topCenter: string;
    /** Content to display in the top-right section */
    topRight: string;
    /** Content to display in the bottom-left section */
    bottomLeft: string;
    /** Content to display in the bottom-center section */
    bottomCenter: string;
    /** Content to display in the bottom-right section */
    bottomRight: string;
}
/**
 * Defines which elements should remain frozen when printing
 */
export declare enum PrintFreeze {
    /** Keep row headers frozen when printing */
    Row = "Row",
    /** Keep column headers frozen when printing */
    Column = "Column"
}
/**
 * Configuration interface for sheet print layout settings
 */
export interface ISheetPrintLayoutConfig {
    /**
     * Specifies which area of the sheet to print (e.g., current sheet, selection)
     */
    area: PrintArea;
    /**
     * List of sub-unit IDs to print, can include specific ranges within units
     */
    subUnitIds: (string | {
        id: string;
        range: IRange;
    })[];
    /**
     * Paper size setting (e.g., A4, Letter)
     */
    paperSize: PaperType;
    /**
     * Page orientation (Portrait or Landscape)
     */
    direction: PrintDirection;
    /**
     * Scale type for fitting content to page
     */
    scale: PrintScale;
    /**
     * Custom scale percentage when scale type is custom
     */
    customScale: number;
    /**
     * Array of freeze settings for rows and columns
     */
    freeze: PrintFreeze[];
    /**
     * Margin preset for the printed page
     */
    margin: PrintPaperMargin;
    /**
     * Custom page dimensions when using custom paper size
     */
    pageSizeCustom?: {
        w: number;
        h: number;
    };
    /**
     * Maximum number of rows to print per page
     */
    maxRowsEachPage: number;
    /**
     * Maximum number of columns to print per page
     */
    maxColumnsEachPage: number;
    marginCustom: IPrintMargin;
}
/**
 * Configuration interface for sheet print rendering options
 */
export interface ISheetPrintRenderConfig {
    /**
     * Whether to show gridlines in the printed output
     */
    gridlines: boolean;
    /**
     * Horizontal alignment setting for content
     */
    hAlign: PrintAlign;
    /**
     * Vertical alignment setting for content
     */
    vAlign: PrintAlign;
    /**
     * Array of header and footer elements to include
     */
    headerFooter: PrintHeaderFooter[];
    /**
     * Detailed settings for header and footer content
     */
    headerFooterSetting: IPrintHeaderFooter;
    /**
     * Whether using custom header/footer instead of presets
     */
    isCustomHeaderFooter?: boolean;
    watermark?: Nullable<IWatermarkConfigWithType>;
}
export declare enum PrintHeaderFooterSymbol {
    WorkbookTitle = "@WorkbookTitle",
    WorksheetTitle = "@WorksheetTitle",
    DateA = "@DateA",
    DateB = "@DateB",
    DateC = "@DateC",
    DateD = "@DateD",
    DateE = "@DateE",
    TimeA = "@TimeA",
    TimeB = "@TimeB",
    TimeC = "@TimeC",
    TimeD = "@TimeD",
    Page = "@Page",
    SheetPage = "@SheetPage",
    PageTotal = "@TotalPage",
    SheetPageTotal = "@TotalSheetPage"
}
export declare const defaultHeaderFooter: IPrintHeaderFooter;
