import type { MenuConfig } from '@univerjs/ui';
export declare const SHEETS_PRINT_PLUGIN_CONFIG_KEY = "sheets-print.config";
export declare const configSymbol: unique symbol;
export interface IUniverSheetsPrintConfig {
    menu?: MenuConfig;
    /**
     * Whether to force the watermark to be displayed when printing
     * @default false
     */
    enforceWatermark?: boolean;
}
export declare const defaultPluginConfig: IUniverSheetsPrintConfig;
