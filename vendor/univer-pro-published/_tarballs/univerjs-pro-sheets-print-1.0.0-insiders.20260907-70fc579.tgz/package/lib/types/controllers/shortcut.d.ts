import type { IShortcutItem } from '@univerjs/ui';
export declare const PrintShortcut: IShortcutItem;
