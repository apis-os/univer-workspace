import { PrintAlign, PrintDirection, PrintPaperMargin, PrintScale } from '@univerjs-pro/print';
import { PrintArea, PrintFreeze, PrintHeaderFooter, PrintHeaderFooterSymbol } from '@univerjs-pro/sheets-print';
import { PaperType } from '@univerjs/core';
import { FEnum } from '@univerjs/core/facade';
/**
 * @ignore
 */
interface IFSheetsPrintEnumMixin {
    /**
     * Print area setting that determines which part of the spreadsheet to print
     */
    PrintArea: typeof PrintArea;
    /**
     * Print alignment settings for content positioning
     */
    PrintAlign: typeof PrintAlign;
    /**
     * Paper size options for printing (e.g., A4, Letter)
     */
    PrintPaperSize: typeof PaperType;
    /**
     * Margin presets for the printed page
     */
    PrintPaperMargin: typeof PrintPaperMargin;
    /**
     * Print scaling options to fit content to page
     */
    PrintScale: typeof PrintScale;
    /**
     * Page orientation setting (Portrait/Landscape)
     */
    PrintDirection: typeof PrintDirection;
    /**
     * Freeze pane settings for printing
     */
    PrintFreeze: typeof PrintFreeze;
    /**
     * Header and footer content options
     */
    PrintHeaderFooter: typeof PrintHeaderFooter;
    /**
     * Special symbols/placeholders available for headers and footers
     */
    PrintHeaderFooterSymbol: typeof PrintHeaderFooterSymbol;
}
export declare class FSheetsPrintEnumMixin extends FEnum implements IFSheetsPrintEnumMixin {
    get PrintArea(): typeof PrintArea;
    get PrintAlign(): typeof PrintAlign;
    get PrintPaperSize(): typeof PaperType;
    get PrintPaperMargin(): typeof PrintPaperMargin;
    get PrintScale(): typeof PrintScale;
    get PrintDirection(): typeof PrintDirection;
    get PrintFreeze(): typeof PrintFreeze;
    get PrintHeaderFooter(): typeof PrintHeaderFooter;
    get PrintHeaderFooterSymbol(): typeof PrintHeaderFooterSymbol;
}
declare module '@univerjs/core/facade' {
    interface FEnum extends IFSheetsPrintEnumMixin {
    }
}
export {};
