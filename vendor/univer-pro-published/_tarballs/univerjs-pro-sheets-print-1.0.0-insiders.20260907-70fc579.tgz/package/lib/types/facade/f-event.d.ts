import type { ISheetPrintLayoutConfig, ISheetPrintRenderConfig } from '@univerjs-pro/sheets-print';
import type { IEventBase } from '@univerjs/core/facade';
import type { FWorkbook, FWorksheet } from '@univerjs/sheets/facade';
/**
 * Event triggered when sheet print dialog is opened
 */
export interface ISheetPrintOpenEventParams extends IEventBase {
    /**
     * The workbook instance being printed
     */
    workbook: FWorkbook;
    /**
     * The specific worksheet being printed
     */
    worksheet: FWorksheet;
}
/**
 * Event triggered when print settings are confirmed by user
 */
export interface ISheetPrintConfirmedEventParams extends IEventBase {
    /**
     * The final layout configuration for printing
     */
    layoutConfig: ISheetPrintLayoutConfig;
    /**
     * The final render configuration for printing
     */
    renderConfig: ISheetPrintRenderConfig;
}
/**
 * Event triggered when print operation is canceled
 */
export interface ISheetPrintCanceledEventParams extends IEventBase {
    /**
     * The layout configuration at time of cancellation
     */
    layoutConfig: ISheetPrintLayoutConfig;
    /**
     * The render configuration at time of cancellation
     */
    renderConfig: ISheetPrintRenderConfig;
}
/**
 * Event triggered before sheet print dialog opens
 */
export interface IBeforeSheetPrintOpenEventParams extends IEventBase {
    /**
     * The workbook instance being printed
     */
    workbook: FWorkbook;
    /**
     * The specific worksheet being printed
     */
    worksheet: FWorksheet;
}
/**
 * Event triggered before print settings are confirmed
 */
export interface IBeforeSheetPrintConfirmEventParams extends IEventBase {
    /**
     * The layout configuration to be applied
     */
    layoutConfig: ISheetPrintLayoutConfig;
    /**
     * The render configuration to be applied
     */
    renderConfig: ISheetPrintRenderConfig;
}
/**
 * Event triggered before print operation is canceled
 */
export interface IBeforeSheetPrintCancelEventParams extends IEventBase {
    /**
     * The layout configuration being canceled
     */
    layoutConfig: ISheetPrintLayoutConfig;
    /**
     * The render configuration being canceled
     */
    renderConfig: ISheetPrintRenderConfig;
}
/**
 * Constants for sheet print event names
 * @ignore
 */
export interface IFSheetsPrintEventNameMixin {
    /**
     * Event triggered before print dialog opens
     * @see {@link IBeforeSheetPrintOpenEventParams}
     *
     * @example
     * ``` ts
     * const disposable = univerAPI.addEvent(univerAPI.Event.BeforeSheetPrintOpen, (params) => {
     *   const { workbook, worksheet } = params;
     *   console.log('params', params);
     *
     *   // Cancel open print configuration dialog operation
     *   params.cancel = true;
     * });
     *
     * // Remove the event listener, use `disposable.dispose()`.
     * ```
     */
    readonly BeforeSheetPrintOpen: 'BeforeSheetPrintOpen';
    /**
     * Event triggered before print settings are confirmed
     * @see {@link IBeforeSheetPrintConfirmEventParams}
     *
     * @example
     * ``` ts
     * const disposable = univerAPI.addEvent(univerAPI.Event.BeforeSheetPrintConfirm, (params) => {
     *   const { renderConfig, layoutConfig } = params;
     *   console.log('params', params);
     *
     *   // Cancel the print confirmation operation
     *   params.cancel = true;
     * });
     *
     * // Remove the event listener, use `disposable.dispose()`.
     * ```
     */
    readonly BeforeSheetPrintConfirm: 'BeforeSheetPrintConfirm';
    /**
     * Event triggered before print operation is canceled
     * @see {@link IBeforeSheetPrintCancelEventParams}
     *
     * @example
     * ``` ts
     * const disposable = univerAPI.addEvent(univerAPI.Event.BeforeSheetPrintCanceled, (params) => {
     *   const { renderConfig, layoutConfig } = params;
     *   console.log('params', params);
     *
     *   // Cancel the print cancel operation
     *   params.cancel = true;
     * });
     *
     * // Remove the event listener, use `disposable.dispose()`.
     * ```
     */
    readonly BeforeSheetPrintCanceled: 'BeforeSheetPrintCanceled';
    /**
     * Event triggered when print dialog opens
     * @see {@link ISheetPrintOpenEventParams}
     *
     * @example
     * ``` ts
     * const disposable = univerAPI.addEvent(univerAPI.Event.SheetPrintOpen, (params) => {
     *   const { workbook, worksheet } = params;
     *   console.log('params', params);
     * });
     *
     * // Remove the event listener, use `disposable.dispose()`.
     * ```
     */
    readonly SheetPrintOpen: 'SheetPrintOpen';
    /**
     * Event triggered when print settings are confirmed
     * @see {@link ISheetPrintConfirmedEventParams}
     *
     * @example
     * ``` ts
     * const disposable = univerAPI.addEvent(univerAPI.Event.SheetPrintConfirmed, (params) => {
     *   const { renderConfig, layoutConfig } = params;
     *   console.log('params', params);
     * });
     *
     * // Remove the event listener, use `disposable.dispose()`.
     * ```
     */
    readonly SheetPrintConfirmed: 'SheetPrintConfirmed';
    /**
     * Event triggered when print operation is canceled
     * @see {@link ISheetPrintCanceledEventParams}
     *
     * @example
     * ``` ts
     * const disposable = univerAPI.addEvent(univerAPI.Event.SheetPrintCanceled, (params) => {
     *   const { renderConfig, layoutConfig } = params;
     *   console.log('params', params);
     * });
     *
     * // Remove the event listener, use `disposable.dispose()`.
     * ```
     */
    readonly SheetPrintCanceled: 'SheetPrintCanceled';
}
/**
 * Event configuration for sheet print events
 * @ignore
 */
export interface ISheetsPrintEventParamConfig {
    BeforeSheetPrintOpen: IBeforeSheetPrintOpenEventParams;
    BeforeSheetPrintConfirm: IBeforeSheetPrintConfirmEventParams;
    BeforeSheetPrintCanceled: IBeforeSheetPrintCancelEventParams;
    SheetPrintOpen: ISheetPrintOpenEventParams;
    SheetPrintConfirmed: ISheetPrintConfirmedEventParams;
    SheetPrintCanceled: ISheetPrintCanceledEventParams;
}
declare module '@univerjs/core/facade' {
    interface FEventName extends IFSheetsPrintEventNameMixin {
    }
    interface IEventParamConfig extends ISheetsPrintEventParamConfig {
    }
}
