import type { ISheetPrintLayoutConfig, ISheetPrintRenderConfig } from '@univerjs-pro/sheets-print';
import { FWorkbook } from '@univerjs/sheets/facade';
/**
 * @ignore
 */
export interface IFWorkbookSheetsPrintMixin {
    /**
     * Update print config, include print area, page-setting, scale, freeze, margin, and etc.
     * @param {ISheetPrintLayoutConfig} config - The print layout config.
     * @returns {FWorkbook} - The current workbook instance for chaining.
     *
     * @example
     * ``` ts
     * const fWorkbook = univerAPI.getActiveWorkbook();
     * const fWorksheet = fWorkbook.getSheetByName('Sheet1');
     * if (!fWorksheet) return;
     * const subUnitId = fWorksheet.getSheetId();
     *
     * // Update print layout config
     * fWorkbook.updatePrintConfig({
     *   area: univerAPI.Enum.PrintArea.CurrentSheet, // print current sheet
     *   subUnitIds: [subUnitId],
     *   paperSize: univerAPI.Enum.PrintPaperSize.A4, // A4 paper size
     *   scale: univerAPI.Enum.PrintScale.FitPage, // fit content to page
     *   freeze: [univerAPI.Enum.PrintFreeze.Row], // freeze row headers
     *   margin: univerAPI.Enum.PrintPaperMargin.Normal, // normal margin
     *   // ... other settings
     * });
     *
     * // Start print
     * fWorkbook.print();
     * ```
     */
    updatePrintConfig(config: ISheetPrintLayoutConfig): FWorkbook;
    /**
     * Update print render config, include print header-footer setting, alignment, gridline, and etc.
     * @param {ISheetPrintRenderConfig} config - The print render config.
     * @returns {FWorkbook} - The current workbook instance for chaining.
     *
     * @example
     * ``` ts
     * const fWorkbook = univerAPI.getActiveWorkbook();
     *
     * // Update print layout config by default
     * fWorkbook.updatePrintConfig({});
     *
     * // Update print render config
     * fWorkbook.updatePrintRenderConfig({
     *   gridlines: true, // show gridlines
     *   hAlign: univerAPI.Enum.PrintAlign.Middle, // horizontal align middle
     *   vAlign: univerAPI.Enum.PrintAlign.Middle, // vertical align middle
     *   headerFooter: [ // the array of header and footer elements to include, here is page numbers and worksheet name
     *     univerAPI.Enum.PrintHeaderFooter.PageSize,
     *     univerAPI.Enum.PrintHeaderFooter.WorksheetTitle
     *   ],
     *   // ... other settings
     * });
     *
     * // Start print
     * fWorkbook.print();
     * ```
     */
    updatePrintRenderConfig(config: ISheetPrintRenderConfig): FWorkbook;
    /**
     * Using current print config and render config to print.
     *
     * @example
     * ``` ts
     * const fWorkbook = univerAPI.getActiveWorkbook();
     *
     * // Update print layout config by default
     * fWorkbook.updatePrintConfig({});
     *
     * // Update print render config by default
     * fWorkbook.updatePrintRenderConfig({});
     *
     * // Start print
     * fWorkbook.print();
     * ```
     */
    print(): void;
    /**
     * Open print preview dialog.
     *
     * @example
     * ``` ts
     * const fWorkbook = univerAPI.getActiveWorkbook();
     * fWorkbook.openPrintDialog();
     * ```
     */
    openPrintDialog(): void;
    /**
     * Close print preview dialog.
     *
     * @example
     * ``` ts
     * const fWorkbook = univerAPI.getActiveWorkbook();
     * fWorkbook.openPrintDialog();
     *
     * // Close print dialog after 3 seconds
     * setTimeout(() => {
     *   fWorkbook.closePrintDialog();
     * }, 3000);
     * ```
     */
    closePrintDialog(): void;
    /**
     * Save screenshot of current range to clipboard.
     * This API is only available with a license. Without a license, usage is restricted, and save operations will return `false`.
     * We use the Clipboard API to save the image to the clipboard, which may fail in an insecure network environment or in some unsupported browsers. A successful save will return `true`.
     * @returns {Promise<boolean>} - The result of saving the screenshot to the clipboard.
     *
     * @example
     * ``` ts
     * const fWorkbook = univerAPI.getActiveWorkbook();
     * const result = await fWorkbook.saveScreenshotToClipboard();
     * console.log(result); // true or false
     * ```
     */
    saveScreenshotToClipboard(): Promise<boolean>;
}
export declare class FWorkbookSheetsPrintMixin extends FWorkbook implements IFWorkbookSheetsPrintMixin {
    updatePrintConfig(config: ISheetPrintLayoutConfig): FWorkbook;
    updatePrintRenderConfig(config: ISheetPrintRenderConfig): FWorkbook;
    print(): void;
    openPrintDialog(): void;
    closePrintDialog(): void;
    saveScreenshotToClipboard(): Promise<boolean>;
}
declare module '@univerjs/sheets/facade' {
    interface FWorkbook extends IFWorkbookSheetsPrintMixin {
    }
}
