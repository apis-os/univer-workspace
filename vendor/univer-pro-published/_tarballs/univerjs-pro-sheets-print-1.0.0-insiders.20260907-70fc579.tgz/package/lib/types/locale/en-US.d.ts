declare const locale: {
    'sheets-print': {
        permission: {
            printErr: string;
        };
        header: {
            total: string;
            pages: string;
            cancel: string;
            next: string;
            printing: string;
        };
        menu: string;
        title: string;
        grid: {
            title: string;
            showGrid: string;
            showGridLabel: string;
            closeAndHide: string;
        };
        screenshot: {
            title: string;
            success: string;
            fail: string;
        };
        size: {
            title: string;
            letter: string;
            tabloid: string;
            legal: string;
            statement: string;
            executive: string;
            folio: string;
            a3: string;
            a4: string;
            a5: string;
            b4: string;
            b5: string;
        };
        margin: {
            title: string;
            normal: string;
            narrow: string;
            wide: string;
            custom: string;
            top: string;
            bottom: string;
            left: string;
            right: string;
        };
        area: {
            title: string;
            currentSheet: string;
            workbook: string;
            currentSelection: string;
            maxRowsEachPage: string;
            maxColumnsEachPage: string;
            limit: string;
            allSelection: string;
        };
        selection: {
            title: string;
            allWorkbook: string;
            workbookUnit: string;
        };
        scale: {
            title: string;
            normal: string;
            fitWidth: string;
            fitHeight: string;
            fitPage: string;
            custom: string;
        };
        orientation: {
            title: string;
            landscape: string;
            portrait: string;
        };
        formatting: {
            title: string;
            skeleton: string;
            waterMark: string;
        };
        align: {
            title: string;
            horizontal: {
                title: string;
                middle: string;
                start: string;
                end: string;
            };
            vertical: {
                title: string;
                start: string;
                end: string;
                middle: string;
            };
        };
        headerFooter: {
            title: string;
            page: string;
            workbook: string;
            sheet: string;
            date: string;
            time: string;
            customHeadFooter: string;
            editCustomHeadFooter: string;
            header: string;
            footer: string;
            left: string;
            right: string;
            center: string;
            dateFormat: string;
            dateA: string;
            dateB: string;
            dateC: string;
            dateD: string;
            dateE: string;
            timeA: string;
            timeB: string;
            timeC: string;
            timeD: string;
            display: {
                page: string;
                title: string;
                sheet: string;
                dateA: string;
                dateB: string;
                dateC: string;
                dateD: string;
                dateE: string;
                dateF: string;
                timeA: string;
                timeB: string;
                timeC: string;
                timeD: string;
                sheetPage: string;
                pageTotal: string;
                sheetPageTotal: string;
            };
            placeholder: string;
            submit: string;
        };
        freeze: {
            title: string;
            desc: string;
            row: string;
            column: string;
        };
        limit: {
            page: string;
            waterMark: string;
            link: string;
        };
    };
};
export default locale;
