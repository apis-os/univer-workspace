import { Disposable } from '@univerjs/core';
import { BehaviorSubject } from 'rxjs';
export interface IPrintGridService {
    visible$: BehaviorSubject<boolean>;
    visible: boolean;
    show(): void;
    hide(): void;
}
export declare const IPrintGridService: import("@wendellhu/redi").IdentifierDecorator<IPrintGridService>;
export declare class PrintGridService extends Disposable implements IPrintGridService {
    private readonly _visible$;
    readonly visible$: BehaviorSubject<boolean>;
    get visible(): boolean;
    show(): void;
    hide(): void;
    dispose(): void;
}
