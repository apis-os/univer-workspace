import type { IPrintMargin } from '@univerjs-pro/print';
import type { IDisposable, IFreeze, IRange } from '@univerjs/core';
import type { Observable } from 'rxjs';
import type { ISheetPrintLayoutConfig, ISheetPrintRenderConfig } from '../common/types';
import { IUniverInstanceService } from '@univerjs/core';
import { IRenderManagerService } from '@univerjs/engine-render';
import { SheetsSelectionsService } from '@univerjs/sheets';
import { SheetPrintInterceptorService } from '@univerjs/sheets-ui';
export declare const DEFAULT_PRINT_LIMIT = 3;
export interface IPrintSheetInfo {
    unitId: string;
    subUnitId: string;
    range: IRange;
    freeze: IFreeze;
    contentSize: {
        w: number;
        h: number;
    };
    scale: number;
}
export interface IPrintRowPage {
    startRow: number;
    endRow: number;
}
export interface IPrintColumnPage {
    startColumn: number;
    endColumn: number;
}
export interface ISheetPrintLayoutInfo {
    pages: IRange[];
    freeze: IFreeze;
    scale: number;
    unitId: string;
    subUnitId: string;
    margin: IPrintMargin;
    pageSize: {
        w: number;
        h: number;
    };
}
export interface ISheetPrintManagerService {
    layoutConfig$: Observable<ISheetPrintLayoutConfig>;
    updateLayoutConfig(config: Partial<ISheetPrintLayoutConfig>): void;
    replaceLayoutConfig(config: ISheetPrintLayoutConfig): void;
    get layoutConfig(): ISheetPrintLayoutConfig;
    renderConfig$: Observable<ISheetPrintRenderConfig>;
    updateRenderConfig(config: Partial<ISheetPrintRenderConfig>): void;
    replaceRenderConfig(config: ISheetPrintRenderConfig): void;
    get renderConfig(): ISheetPrintRenderConfig;
    layoutInfos$: Observable<ISheetPrintLayoutInfo[]>;
    get layoutInfos(): ISheetPrintLayoutInfo[];
    paperSize: {
        w: number;
        h: number;
    };
    paperMargin: IPrintMargin;
    reLayout: () => void;
    reset: () => void;
    setPrintViewDisposable(disposable: IDisposable): void;
    disposePrintView(): void;
}
export declare const ISheetPrintManagerService: import("@wendellhu/redi").IdentifierDecorator<ISheetPrintManagerService>;
export declare const DEFAULT_FREEZE: {
    startColumn: number;
    startRow: number;
    xSplit: number;
    ySplit: number;
};
export declare class SheetPrintManagerService implements ISheetPrintManagerService {
    private readonly _univerInstanceService;
    private readonly _sheetsSelectionsSrv;
    private readonly _sheetPrintInterceptorService;
    private readonly _renderManagerService;
    private _layoutConfig;
    private _renderConfig;
    private _layoutInfos;
    private readonly _layoutInfos$;
    private readonly _layoutConfig$;
    private readonly _renderConfig$;
    private _printViewDisposable;
    readonly layoutConfig$: Observable<ISheetPrintLayoutConfig>;
    readonly renderConfig$: Observable<ISheetPrintRenderConfig>;
    readonly layoutInfos$: Observable<ISheetPrintLayoutInfo[]>;
    constructor(_univerInstanceService: IUniverInstanceService, _sheetsSelectionsSrv: SheetsSelectionsService, _sheetPrintInterceptorService: SheetPrintInterceptorService, _renderManagerService: IRenderManagerService);
    get layoutInfos(): ISheetPrintLayoutInfo[];
    get renderConfig(): ISheetPrintRenderConfig;
    get layoutConfig(): ISheetPrintLayoutConfig;
    get paperSize(): {
        w: number;
        h: number;
    };
    get paperMargin(): IPrintMargin;
    updateLayoutConfig(config: Partial<ISheetPrintLayoutConfig>): void;
    replaceLayoutConfig(config: ISheetPrintLayoutConfig): void;
    updateRenderConfig(config: Partial<ISheetPrintRenderConfig>): void;
    replaceRenderConfig(config: ISheetPrintRenderConfig): void;
    reLayout(): void;
    reset(): void;
    setPrintViewDisposable(disposable: IDisposable): void;
    disposePrintView(): void;
    private _calculate;
    private _calculateSheetRangeById;
    private _calculateCurrentSelectionRange;
    private _calculateFinalRange;
    private _calculatePrintScale;
    private _calculateSubSheetRange;
    private _calculateSheetPages;
}
