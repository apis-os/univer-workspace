import type { ISheetPrintLayoutInfo } from './sheet-print-manager.service';
export declare function calcPages(configs: ISheetPrintLayoutInfo[]): {
    range: import("@univerjs/core").IRange;
    page: number;
    pageTotal: number;
    sheetPageTotal: number;
    sheetPage: number;
    pages: import("@univerjs/core").IRange[];
    freeze: import("@univerjs/core").IFreeze;
    scale: number;
    unitId: string;
    subUnitId: string;
    margin: import("@univerjs-pro/print").IPrintMargin;
    pageSize: {
        w: number;
        h: number;
    };
}[];
