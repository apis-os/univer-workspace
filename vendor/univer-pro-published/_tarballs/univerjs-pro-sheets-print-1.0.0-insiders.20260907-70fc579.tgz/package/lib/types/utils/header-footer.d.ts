import type { DateKit, IDocumentData, LocaleService, Workbook, Worksheet } from '@univerjs/core';
import { PrintHeaderFooterSymbol } from '../common/types';
interface IHeaderFooterContext {
    workbook: Workbook;
    worksheet: Worksheet;
    page: number;
    pageTotal: number;
    localeService: LocaleService;
    now: DateKit;
    sheetPageTotal: number;
    sheetPage: number;
}
export declare function mapHeaderFooterSymbol(symbol: PrintHeaderFooterSymbol, ctx: IHeaderFooterContext): string;
export declare function getHeaderFooterText(text: string, ctx: IHeaderFooterContext): string;
export declare function transformHeaderFooterText(text: string, datas: {
    value: PrintHeaderFooterSymbol;
    label: string;
}[]): IDocumentData;
export declare function parseHeaderFooterText(text: IDocumentData | undefined): string;
export {};
