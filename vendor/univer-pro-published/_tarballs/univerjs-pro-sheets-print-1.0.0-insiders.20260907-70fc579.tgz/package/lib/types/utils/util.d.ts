import type { IAccessor } from '@univerjs/core';
export declare const canUsePrint: (ls?: string, pbk?: string) => boolean;
export declare const getPrintInfoByLicense: (defaultPrintLimit: number, ls?: string, pbk?: string) => {
    page: number;
    isPro: boolean;
    timeValid: boolean;
};
export declare function hasPrintFacadePermission(accessor: IAccessor): boolean;
