import type { IPrintSheetPageInfo } from './sheet-print-canvas-view';
export interface ISheetPrintPageViewProps {
    page: number;
    previewScale: number;
    config: IPrintSheetPageInfo;
}
export declare const DEFAULT_WIDTH = 794;
export declare const SheetPrintPagePreview: import("react").ForwardRefExoticComponent<ISheetPrintPageViewProps & import("react").RefAttributes<HTMLDivElement>>;
