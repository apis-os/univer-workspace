interface IGridProps {
    width?: number;
    height?: number;
    cols?: number;
    rows?: number;
    cellWidth?: number;
    cellHeight?: number;
    strokeColor?: string;
}
export declare function Grid({ width, height, cols, rows, cellWidth, cellHeight, strokeColor, }: IGridProps): import("react").JSX.Element;
export {};
